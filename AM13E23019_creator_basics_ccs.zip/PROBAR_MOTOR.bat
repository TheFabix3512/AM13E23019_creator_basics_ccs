@echo off
rem Prueba: crea y compila los 2 proyectos de motor en ccs_pruebas_motor (SRAM). Se puede borrar.
set W=%~dp0..\ccs_pruebas_motor
set LOG=%~dp0probar_motor.log
echo === %DATE% %TIME% === > "%LOG%"
if exist "%W%" rmdir /s /q "%W%"
mkdir "%W%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREADOR_CCS.ps1" -Tipo sram_motor -Nombre motor_v1 -Destino "%W%" >> "%LOG%" 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREADOR_CCS.ps1" -Tipo sram_motor_timer -Nombre motor_v2 -Destino "%W%" >> "%LOG%" 2>&1
dir /b "%W%\motor_v1\Debug\*.out" "%W%\motor_v2\Debug\*.out" >> "%LOG%" 2>&1
echo === FIN %TIME% === >> "%LOG%"
