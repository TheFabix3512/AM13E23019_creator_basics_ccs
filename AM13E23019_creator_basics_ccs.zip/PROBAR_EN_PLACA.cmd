@echo off
rem Prueba en placa de los proyectos creados (solo SRAM) y de HUELLA_FLASH. Se puede borrar.
set W=%~dp0..\ccs_pruebas_creador
set LOG=%~dp0probar_en_placa.log
set DSLITE=C:\ti\ccs2101\ccs\ccs_base\DebugServer\bin\DSLite.exe
echo === %DATE% %TIME% === > "%LOG%"
echo --- huella 1 --- >> "%LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%W%\prueba_sram_lab\herramientas\HUELLA_FLASH.ps1" >> "%LOG%" 2>&1
echo --- sram_lab --- >> "%LOG%"
"%DSLITE%" load --config="%W%\prueba_sram_lab\targetConfigs\AM13E23019.ccxml" --timeout=30 "%W%\prueba_sram_lab\Debug\prueba_sram_lab.out" >> "%LOG%" 2>&1
timeout /t 2 /nobreak > nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0..\am13e230_lab_v2\PROBAR_LAB.ps1' -Commands 'PING','INFO','BENCH PARK 1000','AES TEST' -LogFile '%W%\r_lab.txt'" >> "%LOG%" 2>&1
echo --- sram (consola) --- >> "%LOG%"
"%DSLITE%" load --config="%W%\prueba_sram\targetConfigs\AM13E23019.ccxml" --timeout=30 "%W%\prueba_sram\Debug\prueba_sram.out" >> "%LOG%" 2>&1
timeout /t 2 /nobreak > nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& '%~dp0..\am13e230_lab_v2\PROBAR_LAB.ps1' -Commands 'PING','LED VERDE','LED OFF' -LogFile '%W%\r_sram.txt'" >> "%LOG%" 2>&1
echo --- huella 2 (debe ser IGUAL) --- >> "%LOG%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%W%\prueba_sram_lab\herramientas\HUELLA_FLASH.ps1" >> "%LOG%" 2>&1
echo === FIN %TIME% === >> "%LOG%"
