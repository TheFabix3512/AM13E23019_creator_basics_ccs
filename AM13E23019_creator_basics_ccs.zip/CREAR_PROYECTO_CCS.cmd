@echo off
rem Crea un proyecto de CCS (SRAM o FLASH) listo para compilar y depurar desde CCS.
title Creador de proyectos CCS - LP-AM13E230
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREADOR_CCS.ps1" %*
echo.
pause
