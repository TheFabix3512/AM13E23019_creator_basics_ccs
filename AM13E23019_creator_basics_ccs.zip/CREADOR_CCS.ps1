param(
    [ValidateSet('', 'sram', 'sram_irq', 'sram_lab', 'sram_motor_test', 'sram_motor', 'sram_motor_timer', 'sram_motor_uart', 'flash')][string]$Tipo = '',
    [string]$Nombre = '',
    [string]$Destino = '',
    [switch]$SinPausa
)
# Crea un proyecto NATIVO de CCS 21 para LP-AM13E230: se compila, carga y depura desde CCS.
$ErrorActionPreference = 'Stop'
$creador = Split-Path -Parent $MyInvocation.MyCommand.Path
$ti = Split-Path -Parent $creador
$cli = 'C:\ti\ccs2101\ccs\eclipse\ccs-server-cli.bat'
$sdkDir = 'C:\ti\am13e230x_sdk_26_01_00_03\am13e230x_sdk_26_01_00_03'

$tipos = [ordered]@{
    'sram'     = @{ t = 'SRAM  - consola UART (PING, HELP, LED) para tus comandos'; dl = @('dl_common.c', 'dl_unicomm.c', 'dl_unicommuart.c') }
    'sram_irq' = @{ t = 'SRAM  - consola con interrupciones (MODO SONDEO/IRQ, ESPERA)'; dl = @('dl_common.c', 'dl_unicomm.c', 'dl_unicommuart.c') }
    'sram_lab' = @{ t = 'SRAM  - laboratorio completo: TMU, Park, integral, CRC, AES, DMA'; dl = @('dl_common.c', 'dl_unicomm.c', 'dl_unicommuart.c', 'dl_crcp.c', 'dl_aes.c', 'dl_dma.c') }
    'sram_motor_test'  = @{ t = 'SRAM  - PRUEBA de cableado PUL/DIR del CL86T (voltajes fijos)'; dl = @('dl_common.c') }
    'sram_motor'       = @{ t = 'SRAM  - motor paso a paso CL86T (PUL/DIR) con busy-wait'; dl = @('dl_common.c') }
    'sram_motor_timer' = @{ t = 'SRAM  - motor paso a paso CL86T con timer + interrupcion'; dl = @('dl_common.c', 'dl_timer.c') }
    'sram_motor_uart'  = @{ t = 'SRAM  - motor CL86T controlado por UART (PASOS +/-, VEL)'; dl = @('dl_common.c', 'dl_unicomm.c', 'dl_unicommuart.c') }
    'flash'    = @{ t = 'FLASH - GPIO basico: LED parpadea, BOOT cambia LED, WAKE velocidad'; dl = @() }
}

Write-Host ''
Write-Host '=== CREADOR DE PROYECTOS CCS - LP-AM13E230 ===' -ForegroundColor Cyan
if ($Tipo -eq '') {
    $i = 1; $llaves = @($tipos.Keys)
    foreach ($k in $llaves) { Write-Host ("  {0}) {1}" -f $i, $tipos[$k].t); $i++ }
    while ($true) {
        $r = Read-Host ("Elige (1-{0})" -f $llaves.Count)
        if (($r -match '^[0-9]+$') -and ([int]$r -ge 1) -and ([int]$r -le $llaves.Count)) { $Tipo = $llaves[[int]$r - 1]; break }
    }
}
$esFlash = ($Tipo -eq 'flash')
if ($esFlash) { Write-Host 'FLASH: al presionar Debug en CCS se REEMPLAZA el programa de la placa.' -ForegroundColor Yellow }
else { Write-Host 'SRAM: al presionar Debug en CCS se carga en memoria temporal. La flash NO se toca.' -ForegroundColor Green }

while ($Nombre -notmatch '^[A-Za-z][A-Za-z0-9_]{0,39}$') {
    if ($Nombre -ne '') { Write-Host 'Nombre no valido: empieza con letra; solo letras, numeros y _.' -ForegroundColor Yellow }
    $Nombre = Read-Host 'Nombre del proyecto (ejemplo: mi_suma)'
}

if ($Destino -eq '') {
    $Destino = Join-Path $ti 'ccs_proyectos'
    New-Item -ItemType Directory -Force -Path $Destino | Out-Null
    Write-Host "Elige en la ventana la carpeta de trabajo de CCS (si la cierras: $Destino)"
    Add-Type -AssemblyName System.Windows.Forms
    $d = New-Object System.Windows.Forms.FolderBrowserDialog
    $d.Description = 'Carpeta de trabajo (workspace) de CCS donde se creara el proyecto'
    $d.SelectedPath = $Destino
    $d.ShowNewFolderButton = $true
    if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $Destino = $d.SelectedPath }
}
New-Item -ItemType Directory -Force -Path $Destino | Out-Null
$Destino = (Resolve-Path -LiteralPath $Destino).Path.TrimEnd('\')
$proyecto = Join-Path $Destino $Nombre
if (Test-Path -LiteralPath $proyecto) { throw "Ya existe $proyecto. No se sobrescribe; elige otro nombre." }

# 1. Preparar archivos en una carpeta temporal
$tmp = Join-Path $env:TEMP "creador_ccs_$Nombre"
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Path $tmp | Out-Null
$main = [IO.File]::ReadAllText((Join-Path $creador "plantillas\$Tipo\main.c")).Replace('__NOMBRE__', $Nombre)
[IO.File]::WriteAllText((Join-Path $tmp 'main.c'), $main, [Text.Encoding]::ASCII)
Copy-Item (Join-Path $creador 'plantillas\comun\arranque_ccs.c') $tmp
$linker = if ($esFlash) { 'linker_flash_ccs.cmd' } else { 'linker_sram_ccs.cmd' }
Copy-Item (Join-Path $creador "plantillas\comun\$linker") $tmp

$sdk = '${COM_TI_AM13E230X_SDK_INSTALL_DIR}'
$links = ''
foreach ($f in $tipos[$Tipo].dl) { $links += "    <file action=`"link`" path=`"$sdk/source/driverlib/am13e230x/$f`" targetDirectory=`"sdk`"/>`r`n" }
$modo = if ($esFlash) { 'flash' } else { 'sram' }
$post = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File &quot;`${PROJECT_LOC}/herramientas/VERIFICAR_IMAGEN.ps1&quot; -Imagen &quot;`${ProjName}.out&quot; -Modo $modo"
$spec = @"
<projectSpec>
  <project name="$Nombre" device="AM13E23019" deviceCore="CORTEX_M33" cgtVersion="5.1.1.LTS"
        toolChain="TICLANG" connection="TIXDS110_Connection.xml" endianness="little"
        outputFormat="ELF" outputType="executable" products="AM13E2X-SDK" enableSysConfigTool="false"
        compilerBuildOptions="-mcpu=cortex-m33 -march=armv8.1-m.main+cdecp0 -mthumb -mfpu=fpv5-sp-d16 -mfloat-abi=hard -O2 -g -Wall -Wno-unused-command-line-argument
            -I$sdk/source/device/am13e230x/include -I$sdk/source/device/am13e230x/include/hw
            -I$sdk/source/cmsis/Core/Include -I$sdk/source/driverlib/am13e230x"
        linkerBuildOptions="-Wl,--rom_model -Wl,--entry_point=Reset_Handler -Wl,--warn_sections -Wl,--diag_suppress=10063"
        postBuildStep="$post">
    <configuration name="Debug" compilerBuildOptions="" linkerBuildOptions=""/>
    <file action="copy" path="main.c" targetDirectory="." openOnCreation="true"/>
    <file action="copy" path="arranque_ccs.c" targetDirectory="."/>
    <file action="copy" path="$linker" targetDirectory="."/>
    <file action="link" path="$sdk/source/device/am13e230x/src/startup_ti_arm_clang.c" targetDirectory="sdk"/>
$links  </project>
</projectSpec>
"@
$specPath = Join-Path $tmp "$Nombre.projectspec"
[IO.File]::WriteAllText($specPath, $spec, [Text.Encoding]::ASCII)

function CCS([string]$argumentos) {
    # Se llama por cmd.exe: PowerShell parte mal los argumentos tipo -ccs.algo
    $bat = Join-Path $tmp 'cli.bat'
    [IO.File]::WriteAllText($bat, "@echo off`r`nset COM_TI_AM13E230X_SDK_INSTALL_DIR=$sdkDir`r`ncall `"$cli`" $argumentos`r`n", [Text.Encoding]::ASCII)
    & cmd.exe /c $bat
}

# 2. Crear el proyecto en el workspace
Write-Host ''
Write-Host "Creando $proyecto ..."
CCS "-workspace `"$Destino`" -application projectCreate -ccs.projectSpec `"$specPath`""
if (-not (Test-Path -LiteralPath (Join-Path $proyecto '.project'))) { throw 'CCS no creo el proyecto (revisa los mensajes de arriba).' }

# 3. Herramientas (.bat, no .cmd: CCS toma los .cmd como archivos del linker)
$h = Join-Path $proyecto 'herramientas'
New-Item -ItemType Directory -Path $h | Out-Null
foreach ($f in 'VERIFICAR_IMAGEN.ps1', 'HUELLA_FLASH.ps1') { Copy-Item (Join-Path $creador "plantillas\comun\$f") $h }
$js = [IO.File]::ReadAllText((Join-Path $creador 'plantillas\comun\REINICIAR.js')).Replace('__RUTA__', ($proyecto -replace '\\', '/'))
[IO.File]::WriteAllText((Join-Path $h 'REINICIAR.js'), $js, [Text.Encoding]::ASCII)
Copy-Item (Join-Path $creador 'plantillas\comun\HUELLA_FLASH.bat') $proyecto
if (-not $esFlash) {
    Copy-Item (Join-Path $creador 'plantillas\comun\CONSOLA_UART.ps1') $h
    Copy-Item (Join-Path $creador 'plantillas\comun\CONSOLA_UART.bat') $proyecto
}
$extra = Join-Path $creador "plantillas\$Tipo\LEEME_CONEXION.txt"
if (Test-Path $extra) { Copy-Item $extra $proyecto }
$leeme = [IO.File]::ReadAllText((Join-Path $creador "plantillas\LEEME_$modo.txt")).Replace('__NOMBRE__', $Nombre).Replace('__WS__', $Destino)
[IO.File]::WriteAllText((Join-Path $proyecto 'LEEME.txt'), $leeme, [Text.Encoding]::ASCII)

# 4. Primera compilacion (incluye la verificacion de direcciones)
Write-Host ''
Write-Host 'Compilando por primera vez...'
CCS "-workspace `"$Destino`" -application buildProject -ccs.projects $Nombre -ccs.buildType full -ccs.configuration Debug -ccs.listProblems"
Remove-Item $tmp -Recurse -Force
$out = Join-Path $proyecto "Debug\$Nombre.out"
Write-Host ''
if (Test-Path $out) {
    Write-Host "PROYECTO LISTO: $proyecto" -ForegroundColor Green
    Write-Host "En CCS: File > Open Folder > $Destino   y luego Debug (lee LEEME.txt)."
} else {
    Write-Host 'El proyecto se creo pero NO compilo. Abrelo en CCS para ver los errores.' -ForegroundColor Red
}
