@echo off
rem Prueba: crea y compila los 4 tipos en TI\ccs_pruebas_creador. No toca la placa. Se puede borrar.
set W=%~dp0..\ccs_pruebas_creador
set LOG=%~dp0probar_creador_ccs.log
echo === %DATE% %TIME% === > "%LOG%"
for %%T in (sram sram_irq sram_lab flash) do powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREADOR_CCS.ps1" -Tipo %%T -Nombre prueba_%%T -Destino "%W%" >> "%LOG%" 2>&1
dir /s /b "%W%\*.out" >> "%LOG%" 2>&1
echo === FIN %TIME% === >> "%LOG%"
