/*
 * ==========================================================================
 *  Proyecto: __NOMBRE__   (SRAM: la flash no se toca)
 *  LP-AM13E230 (AM13E23019).
 *
 *  Compara dos formas de recibir por la UART:
 *    MODO SONDEO : el main pregunta "llego algo?" todo el tiempo.
 *    MODO IRQ    : la UART "toca el timbre" y UC1_IRQHandler guarda el byte.
 *
 *  Comandos:
 *    PING, HELP, LED ROJO|VERDE|OFF
 *    MODO SONDEO | MODO IRQ   cambiar la forma de recibir
 *    ESPERA ms                la CPU se queda ocupada "ms" milisegundos;
 *                             escribe algo mientras y al final dice cuantos
 *                             bytes sobrevivieron
 *    ESTADO                   modo, interrupciones atendidas, bytes perdidos
 *
 *  Las 3 piezas de la interrupcion estan marcadas con "PIEZA 1/2/3".
 * ==========================================================================
 */

/* -------------------------------------------------------------------------
 * 1. INCLUDES
 * ------------------------------------------------------------------------- */
#include <stdbool.h>
#include <stdint.h>

#include "hw/soc.h"            /* nombres y direcciones de los registros */
#include "dl_gpio.h"           /* pines */
#include "dl_unicomm.h"        /* bloque UNICOMM (UART/I2C/SPI) */
#include "dl_unicommuart.h"    /* funciones DL_UART_... */

/* -------------------------------------------------------------------------
 * 2. CONFIGURACION
 * ------------------------------------------------------------------------- */
#define CPU_CLOCK_HZ        (32000000UL)   /* reloj por defecto, sin PLL */
#define UART_BAUD           (115200UL)
#define LED_ROJO            (1UL << 5)     /* PA5, activo en bajo */
#define LED_VERDE           (1UL << 0)     /* PB0, activo en bajo */
#define LINEA_MAX           (64U)          /* largo maximo de un comando */
#define PALABRAS_MAX        (8U)           /* maximo de palabras por comando */
#define BUZON_TAM           (64U)          /* bytes que guarda el handler */

/* Cronometro del nucleo (cuenta ciclos de 32 MHz) */
#define DEMCR               (*(volatile uint32_t *)0xE000EDFCUL)
#define DWT_CTRL            (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT          (*(volatile uint32_t *)0xE0001004UL)

/* -------------------------------------------------------------------------
 * 3. VARIABLES GLOBALES
 * ------------------------------------------------------------------------- */
static char g_linea[LINEA_MAX];   /* aqui se juntan las letras que llegan */
static uint32_t g_largo;          /* cuantas letras van */

/* PIEZA 1: el buzon compartido entre el handler y el main.
 * volatile = "esto cambia por fuera del main, siempre leelo de memoria". */
static volatile uint8_t  g_buzon[BUZON_TAM];
static volatile uint32_t g_entra;          /* lo mueve SOLO el handler */
static volatile uint32_t g_sale;           /* lo mueve SOLO el main    */
static volatile uint32_t g_irq_veces;      /* cuantas veces sono el timbre */
static volatile uint32_t g_perdidos;       /* bytes tirados por buzon lleno */
static bool g_modo_irq;                    /* false = sondeo, true = IRQ */

/* -------------------------------------------------------------------------
 * 4. ARRANQUE: lo llama Reset_Handler antes de main
 * ------------------------------------------------------------------------- */
void SystemInit(void)
{
    (*(volatile uint32_t *)0xE000ED88UL) = 0x00F00003UL;  /* CPACR: FPU + TMU */
    (*(volatile uint32_t *)0xE000ED08UL) = 0x20000000UL;  /* VTOR: vectores en SRAM */
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

/* -------------------------------------------------------------------------
 * 5. INICIALIZACION DE PERIFERICOS
 *    Receta: reset -> encender -> esperar -> pines -> configurar -> habilitar
 * ------------------------------------------------------------------------- */
static void espera_corta(void)
{
    for (volatile uint32_t i = 0; i < 64UL; ++i) { }
}

static void leds_init(void)
{
    GPIO0->GPRCM.RSTCTL = GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETSTKYCLR_CLR | GPIO_RSTCTL_RESETASSERT_ASSERT;
    GPIO1->GPRCM.RSTCTL = GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETSTKYCLR_CLR | GPIO_RSTCTL_RESETASSERT_ASSERT;
    GPIO0->GPRCM.PWREN  = GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE;
    GPIO1->GPRCM.PWREN  = GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE;
    espera_corta();

    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PA5] = IOMUX_PINCM_PC_CONNECTED | 0x1UL;  /* PA5 = GPIO */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PB0] = IOMUX_PINCM_PC_CONNECTED | 0x1UL;  /* PB0 = GPIO */
    GPIO0->DOUTSET31_0 = LED_ROJO;     /* 1 = apagado */
    GPIO1->DOUTSET31_0 = LED_VERDE;
    GPIO0->DOESET31_0  = LED_ROJO;     /* como salidas */
    GPIO1->DOESET31_0  = LED_VERDE;
}

static void uart_init(void)
{
    DL_UART_Config config = {
        .mode        = DL_UART_MODE_NORMAL,
        .direction   = DL_UART_DIRECTION_TX_RX,
        .flowControl = DL_UART_FLOW_CONTROL_NONE,
        .parity      = DL_UART_PARITY_NONE,
        .wordLength  = DL_UART_WORD_LENGTH_8_BITS,
        .stopBits    = DL_UART_STOP_BITS_ONE,
    };
    DL_UART_ClockConfig clock_config = {
        .clockSel    = DL_UART_CLOCK_BUSCLK,
        .divideRatio = DL_UART_CLOCK_DIVIDE_RATIO_1,
    };

    /* 1) pines  2) reset  3) encender  4) modo UART  5) configurar  6) habilitar */
    DL_GPIO_initPeripheralOutputFunction(IOMUX_PINCM_PA0, IOMUX_PA0_UC1_TX_SDA_PICO);
    DL_GPIO_initPeripheralInputFunction(IOMUX_PINCM_PA1, IOMUX_PA1_UC1_RX_SCL_SCLK);
    DL_UART_reset(UC1_INST_PTR);
    DL_UART_enablePower(UC1_INST_PTR);
    while (!DL_UART_isPowerEnabled(UC1_INST_PTR)) { }
    DL_UNICOMM_setIPMode(UC1_INST_PTR, DL_UNICOMM_UART);
    DL_UART_disable(UC1_INST_PTR);
    DL_UART_init(UC1_INST_PTR, &config);
    DL_UART_setClockConfig(UC1_INST_PTR, &clock_config);
    DL_UART_configBaudRate(UC1_INST_PTR, CPU_CLOCK_HZ, UART_BAUD);
    DL_UART_enable(UC1_INST_PTR);
}

static void cronometro_init(void)
{
    DEMCR |= (1UL << 24);    /* habilitar DWT */
    DWT_CYCCNT = 0UL;
    DWT_CTRL |= 1UL;         /* empezar a contar */
}

/* -------------------------------------------------------------------------
 * PIEZA 2: encender / apagar el timbre (2 lugares: periferico y NVIC)
 * ------------------------------------------------------------------------- */
static void irq_encender(void)
{
    /* (a) en el periferico: "avisame cuando haya al menos 1 byte" */
    DL_UART_setRXFIFOThreshold(UC1_INST_PTR, DL_UART_RX_FIFO_LEVEL_NOT_EMPTY);
    DL_UART_clearInterruptStatus(UC1_INST_PTR, DL_UART_INTERRUPT_RX);
    DL_UART_enableInterrupt(UC1_INST_PTR, DL_UART_INTERRUPT_RX);

    /* (b) en el NVIC del nucleo: dejar pasar la linea de UC1 */
    NVIC_ClearPendingIRQ(UC1_INT_IRQn);
    NVIC_EnableIRQ(UC1_INT_IRQn);
}

static void irq_apagar(void)
{
    NVIC_DisableIRQ(UC1_INT_IRQn);
    DL_UART_disableInterrupt(UC1_INST_PTR, DL_UART_INTERRUPT_RX);
}

/* -------------------------------------------------------------------------
 * PIEZA 3: el handler. El nombre es EXACTO al del startup
 * (startup_keil_arm_clang.S). Nadie lo llama: el hardware salta aqui solo.
 * ------------------------------------------------------------------------- */
void UC1_IRQHandler(void)
{
    ++g_irq_veces;

    /* Leer IIDX dice quien toco el timbre y apaga esa bandera */
    if (DL_UART_getPendingInterrupt(UC1_INST_PTR) == DL_UART_IIDX_RX)
    {
        while (!DL_UART_isRXFIFOEmpty(UC1_INST_PTR))       /* vaciar todo */
        {
            const uint8_t c = DL_UART_receiveData(UC1_INST_PTR);
            const uint32_t siguiente = (g_entra + 1U) % BUZON_TAM;
            if (siguiente != g_sale)
            {
                g_buzon[g_entra] = c;
                g_entra = siguiente;
            }
            else
            {
                ++g_perdidos;                              /* buzon lleno */
            }
        }
    }
    /* corto: guardar y salir. Nada de imprimir aqui. */
}

/* Sacar un byte: primero del buzon; en modo sondeo, directo de la UART */
static bool obtener_byte(uint8_t *c)
{
    if (g_sale != g_entra)
    {
        *c = g_buzon[g_sale];
        g_sale = (g_sale + 1U) % BUZON_TAM;
        return true;
    }
    if (!g_modo_irq)
    {
        return DL_UART_receiveDataCheck(UC1_INST_PTR, c);
    }
    return false;
}

/* -------------------------------------------------------------------------
 * 6. FUNCIONES DE AYUDA
 *    __attribute__((unused)) solo le dice al compilador "todavia no la uso,
 *    no me avises": son herramientas listas para tus comandos.
 * ------------------------------------------------------------------------- */
static void uart_putc(char c)
{
    DL_UART_transmitDataBlocking(UC1_INST_PTR, (uint8_t)c);
}

static void uart_puts(const char *s)
{
    while (*s != '\0') uart_putc(*s++);
}

/* Imprimir un entero sin signo: 1234 -> "1234" */
static void uart_put_u32(uint32_t v)
{
    char d[10];
    uint32_t n = 0U;
    if (v == 0UL) { uart_putc('0'); return; }
    while (v != 0UL) { d[n++] = (char)('0' + (v % 10UL)); v /= 10UL; }
    while (n != 0U) uart_putc(d[--n]);
}

/* Imprimir un decimal con 6 decimales: 3.5 -> "3.500000" */
__attribute__((unused)) static void uart_put_float(float v)
{
    if (v < 0.0f) { uart_putc('-'); v = -v; }
    uint32_t entero = (uint32_t)v;
    uint32_t frac = (uint32_t)((v - (float)entero) * 1000000.0f + 0.5f);
    if (frac >= 1000000UL) { ++entero; frac -= 1000000UL; }
    uart_put_u32(entero);
    uart_putc('.');
    for (uint32_t div = 100000UL; div != 0UL; div /= 10UL) uart_putc((char)('0' + ((frac / div) % 10UL)));
}

/* "> " = termine de responder, manda otro comando */
static void prompt(void)
{
    uart_puts("\r\n> ");
}

static void leds(bool rojo, bool verde)
{
    GPIO0->DOUTSET31_0 = LED_ROJO;                    /* apagar los dos */
    GPIO1->DOUTSET31_0 = LED_VERDE;
    if (rojo)  GPIO0->DOUTCLR31_0 = LED_ROJO;         /* 0 = encendido */
    if (verde) GPIO1->DOUTCLR31_0 = LED_VERDE;
}

/* Comparar palabras sin importar mayusculas */
static bool igual(const char *a, const char *b)
{
    while ((*a != '\0') && (*b != '\0'))
    {
        char x = *a++, y = *b++;
        if ((x >= 'a') && (x <= 'z')) x = (char)(x - 32);
        if ((y >= 'a') && (y <= 'z')) y = (char)(y - 32);
        if (x != y) return false;
    }
    return (*a == '\0') && (*b == '\0');
}

/* Partir la linea en palabras; devuelve cuantas hay */
static uint32_t partir(char *linea, char **pal, uint32_t max)
{
    uint32_t n = 0U;
    while ((*linea != '\0') && (n < max))
    {
        while (*linea == ' ') ++linea;
        if (*linea == '\0') break;
        pal[n++] = linea;
        while ((*linea != '\0') && (*linea != ' ')) ++linea;
        if (*linea != '\0') *linea++ = '\0';
    }
    return n;
}

/* Texto -> entero sin signo. false si no es un numero. */
static bool leer_entero(const char *t, uint32_t *v)
{
    uint32_t r = 0UL;
    if (*t == '\0') return false;
    while (*t != '\0')
    {
        if ((*t < '0') || (*t > '9')) return false;
        r = (r * 10UL) + (uint32_t)(*t++ - '0');
    }
    *v = r;
    return true;
}

/* Texto -> decimal ("-1.5"). false si no es un numero. */
__attribute__((unused)) static bool leer_decimal(const char *t, float *v)
{
    bool neg = false, alguno = false;
    float r = 0.0f, escala = 0.1f;
    if (*t == '-') { neg = true; ++t; }
    while ((*t >= '0') && (*t <= '9')) { alguno = true; r = r * 10.0f + (float)(*t++ - '0'); }
    if (*t == '.')
    {
        ++t;
        while ((*t >= '0') && (*t <= '9')) { alguno = true; r += (float)(*t++ - '0') * escala; escala *= 0.1f; }
    }
    if (!alguno || (*t != '\0')) return false;
    *v = neg ? -r : r;
    return true;
}

/* -------------------------------------------------------------------------
 * 7. COMANDOS: cada uno sigue el molde VALIDAR -> HACER -> RESPONDER
 *    pal[0] es la primera palabra, pal[1] la segunda...; n = cuantas hay
 * ------------------------------------------------------------------------- */
static void cmd_led(char **pal, uint32_t n)
{
    /* 1. VALIDAR */
    if (n != 2U)
    {
        uart_puts("ERR uso: LED ROJO | LED VERDE | LED OFF");
        return;
    }
    /* 2. HACER  y  3. RESPONDER */
    if (igual(pal[1], "ROJO"))       { leds(true, false);  uart_puts("OK LED=ROJO"); }
    else if (igual(pal[1], "VERDE")) { leds(false, true);  uart_puts("OK LED=VERDE"); }
    else if (igual(pal[1], "OFF"))   { leds(false, false); uart_puts("OK LED=OFF"); }
    else                             { uart_puts("ERR uso: LED ROJO | LED VERDE | LED OFF"); }
}

static void cmd_modo(char **pal, uint32_t n)
{
    if ((n == 2U) && igual(pal[1], "IRQ"))
    {
        irq_encender();
        g_modo_irq = true;
        uart_puts("OK MODO=IRQ (recibe UC1_IRQHandler)");
    }
    else if ((n == 2U) && igual(pal[1], "SONDEO"))
    {
        irq_apagar();
        g_modo_irq = false;
        uart_puts("OK MODO=SONDEO (el main pregunta)");
    }
    else
    {
        uart_puts("ERR uso: MODO SONDEO | MODO IRQ");
    }
}

/* La CPU se queda ocupada sin leer la UART. Lo que escribas mientras:
 *   - en SONDEO solo cabe en la FIFO del hardware (unos pocos bytes)
 *   - en IRQ el handler lo va guardando en el buzon                    */
static void cmd_espera(char **pal, uint32_t n)
{
    uint32_t ms;
    if ((n != 2U) || !leer_entero(pal[1], &ms) || (ms == 0UL) || (ms > 5000UL))
    {
        uart_puts("ERR uso: ESPERA ms   (1 a 5000)");
        return;
    }

    uart_puts("Ocupado ");
    uart_put_u32(ms);
    uart_puts(" ms. Escribe algo YA...\r\n");
    while (!DL_UART_isTXFIFOEmpty(UC1_INST_PTR)) { }   /* terminar de enviar */

    DL_UART_clearInterruptStatus(UC1_INST_PTR, DL_UART_INTERRUPT_OVERRUN_ERROR);
    const uint32_t irq_antes = g_irq_veces;

    /* --- trabajo "lento": la CPU no toca la UART --- */
    const uint32_t t0 = DWT_CYCCNT;
    while ((DWT_CYCCNT - t0) < (ms * (CPU_CLOCK_HZ / 1000UL))) { }

    /* recoger lo que sobrevivio */
    char texto[BUZON_TAM + 1U];
    uint32_t cuantos = 0U;
    uint8_t c;
    while (obtener_byte(&c))
    {
        if ((cuantos < BUZON_TAM) && (c >= 32U) && (c <= 126U)) texto[cuantos] = (char)c;
        else if (cuantos < BUZON_TAM) texto[cuantos] = '.';
        if (cuantos < BUZON_TAM) ++cuantos;
    }
    texto[cuantos] = '\0';
    const bool desborde = DL_UART_getRawInterruptStatus(UC1_INST_PTR, DL_UART_INTERRUPT_OVERRUN_ERROR) != 0UL;
    DL_UART_clearInterruptStatus(UC1_INST_PTR, DL_UART_INTERRUPT_OVERRUN_ERROR);

    uart_puts(g_modo_irq ? "[IRQ] " : "[SONDEO] ");
    uart_puts("recibi ");
    uart_put_u32(cuantos);
    uart_puts(" bytes: \"");
    uart_puts(texto);
    uart_puts("\"\r\n  desborde de la FIFO (se perdieron bytes): ");
    uart_puts(desborde ? "SI" : "NO");
    uart_puts("\r\n  interrupciones durante la espera: ");
    uart_put_u32(g_irq_veces - irq_antes);
}

static void cmd_estado(void)
{
    uart_puts(g_modo_irq ? "MODO=IRQ" : "MODO=SONDEO");
    uart_puts("  interrupciones=");
    uart_put_u32(g_irq_veces);
    uart_puts("  perdidos_buzon=");
    uart_put_u32(g_perdidos);
}

/* El despachador: mira la primera palabra y llama al comando */
static void ejecutar(char *linea)
{
    char *pal[PALABRAS_MAX];
    const uint32_t n = partir(linea, pal, PALABRAS_MAX);
    if (n == 0U) { prompt(); return; }

    if (igual(pal[0], "PING"))      { uart_puts("PONG __NOMBRE__"); }
    else if (igual(pal[0], "HELP")) { uart_puts("PING | LED ROJO|VERDE|OFF | MODO SONDEO|IRQ | ESPERA ms | ESTADO"); }
    else if (igual(pal[0], "LED"))  { cmd_led(pal, n); }
    else if (igual(pal[0], "MODO")) { cmd_modo(pal, n); }
    else if (igual(pal[0], "ESPERA")) { cmd_espera(pal, n); }
    else if (igual(pal[0], "ESTADO")) { cmd_estado(); }
    else                            { uart_puts("ERR comando desconocido. Escriba HELP"); }
    prompt();
}

/* Juntar letras hasta el Enter y ejecutar (vengan del buzon o de la UART) */
static void revisar_uart(void)
{
    uint8_t c;
    while (obtener_byte(&c))
    {
        if ((c == '\r') || (c == '\n'))
        {
            if (g_largo != 0U)
            {
                g_linea[g_largo] = '\0';
                uart_puts("\r\n");
                ejecutar(g_linea);
                g_largo = 0U;
            }
        }
        else if (((c == '\b') || (c == 0x7F)) && (g_largo != 0U))
        {
            --g_largo;
            uart_puts("\b \b");                /* borrar en pantalla */
        }
        else if ((c >= 32U) && (c <= 126U) && (g_largo < (LINEA_MAX - 1U)))
        {
            g_linea[g_largo++] = (char)c;
            uart_putc((char)c);                /* eco */
        }
    }
}

/* -------------------------------------------------------------------------
 * 8. MAIN: inicializar una vez y repetir para siempre
 * ------------------------------------------------------------------------- */
int main(void)
{
    SystemInit();       /* por si el cargador no paso por Reset_Handler */
    leds_init();
    uart_init();
    cronometro_init();

    uart_puts("\r\n__NOMBRE__ LISTO (SRAM). Escriba HELP");
    prompt();

    for (;;)
    {
        revisar_uart();
        /* aqui puedes poner otro trabajo que deba repetirse */
    }
}
