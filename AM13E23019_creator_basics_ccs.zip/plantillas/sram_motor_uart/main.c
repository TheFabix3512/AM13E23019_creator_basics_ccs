/*
 * ==========================================================================
 *  Proyecto: __NOMBRE__   (SRAM: la flash NO se toca)
 *  Motor paso a paso CL86T: se controla por UART Y por el boton fisico,
 *  los dos al mismo tiempo (el que uses, manda).
 *
 *  Conexion (ver LEEME_CONEXION.txt): PA3 -> PUL (via transistor),
 *  PA27 -> DIR (via transistor).
 *
 *  BOTON PB13 (WAKE):
 *    - Pulsacion CORTA: arranca (si esta parado) o frena (si esta girando).
 *    - Pulsacion LARGA (>= 800 ms): invierte el giro (frena, invierte,
 *      vuelve a acelerar).
 *
 *  UART (consola del XDS110, 115200 8N1, escribe el comando y Enter):
 *    ARRANCA       Arranca y gira sin parar, a la velocidad VEL actual.
 *    PARA          Frena con rampa (no de golpe) hasta detenerse.
 *    GIRA          Invierte el sentido. Si esta girando: frena, invierte
 *                  y vuelve a acelerar. Si esta parado: solo cambia el
 *                  sentido para el proximo ARRANCA.
 *    VEL <hz>      Cambia la velocidad de crucero (200-4000 Hz). Se puede
 *                  mandar en cualquier momento, incluso girando.
 *    PASOS <n>     Mueve exactamente n pasos y se detiene solo. Positivo
 *                  = horario, negativo = antihorario. Ej: PASOS -800
 *    ESTADO        Dice si esta parado o girando, sentido y velocidad.
 *    PING / HELP
 *
 *  LED rojo (PA5) = detenido.  LED verde (PB0) = girando.
 *  1600 pulsos/vuelta: "PASOS 1600" = una vuelta completa.
 * ==========================================================================
 */

/* -------------------------------------------------------------------------
 * 1. INCLUDES
 * ------------------------------------------------------------------------- */
#include <stdbool.h>
#include <stdint.h>

#include "hw/soc.h"             /* registros y nombres de pines */
#include "dl_gpio.h"            /* DL_GPIO_... */
#include "dl_unicomm.h"         /* bloque UNICOMM (UART/I2C/SPI) */
#include "dl_unicommuart.h"     /* DL_UART_... */

/* -------------------------------------------------------------------------
 * 2. CONFIGURACION Y PINES
 * ------------------------------------------------------------------------- */
#define CPU_CLOCK_HZ    (32000000UL)       /* reloj por defecto, sin PLL */
#define UART_BAUD       (115200UL)
#define LINEA_MAX       (64U)
#define PALABRAS_MAX    (4U)

#define PUL_PORT        GPIO0              /* PA3  */
#define PUL_PIN         DL_GPIO_PIN(3)
#define PUL_IOMUX       IOMUX_PINCM_PA3
#define DIR_PORT        GPIO0              /* PA27 */
#define DIR_PIN         DL_GPIO_PIN(27)
#define DIR_IOMUX       IOMUX_PINCM_PA27
#define ROJO_PORT       GPIO0              /* PA5, activo en bajo: detenido */
#define ROJO_PIN        DL_GPIO_PIN(5)
#define VERDE_PORT      GPIO1              /* PB0, activo en bajo: girando */
#define VERDE_PIN       DL_GPIO_PIN(0)
#define BOTON_PORT      GPIO1              /* PB13 WAKE: 0 = presionado */
#define BOTON_PIN       DL_GPIO_PIN(13)

#define F_MIN_HZ        200U     /* arranque y paro */
#define F_MAX_DEFECTO   2000U    /* crucero por defecto */
#define F_MAX_TOPE      4000U    /* no dejamos poner mas que esto con VEL */
#define RAMPA_PASOS     800U     /* pasos para ir de F_MIN a crucero */
#define PULSO_US        10U      /* el CL86T pide >= 1 us */
#define DIR_SETUP_US    20U      /* el CL86T pide >= 2 us antes del pulso */

#define ANTIRREBOTE_US  20000U   /* 20 ms  */
#define LARGO_US        800000U  /* 800 ms = pulsacion larga */

typedef enum { PARADO, ACELERANDO, CRUCERO, FRENANDO } Estado;

/* -------------------------------------------------------------------------
 * 3. VARIABLES GLOBALES
 * ------------------------------------------------------------------------- */
static char     g_linea[LINEA_MAX];
static uint32_t g_largo;

static volatile Estado   g_estado = PARADO;
static volatile bool     g_horario = true;
static volatile bool     g_invertir;        /* pendiente invertir cuando llegue a 0 */
static uint32_t          g_r;               /* posicion dentro de la rampa actual */
static uint32_t          g_rampa_usada = RAMPA_PASOS;
static uint32_t          g_objetivo;        /* 0 = continuo; >0 = PASOS pedidos */
static uint32_t          g_pasos_dados;
static uint32_t          g_vel_max = F_MAX_DEFECTO;
static uint32_t          g_ahora_us;

/* -------------------------------------------------------------------------
 * 4. ARRANQUE: lo llama Reset_Handler antes de main
 * ------------------------------------------------------------------------- */
void SystemInit(void)
{
    (*(volatile uint32_t *)0xE000ED88UL) = 0x00F00003UL;  /* CPACR: FPU + TMU */
    (*(volatile uint32_t *)0xE000ED08UL) = 0x20000000UL;  /* VTOR: vectores en SRAM */
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

/* -------------------------------------------------------------------------
 * 5. INICIALIZACION DE PERIFERICOS
 * ------------------------------------------------------------------------- */
static void gpio_init(void)
{
    DL_GPIO_reset(GPIO0);
    DL_GPIO_reset(GPIO1);
    DL_GPIO_enablePower(GPIO0);
    DL_GPIO_enablePower(GPIO1);
    while (!DL_GPIO_isPowerEnabled(GPIO0) || !DL_GPIO_isPowerEnabled(GPIO1)) { }

    DL_GPIO_initDigitalOutput(PUL_IOMUX);
    DL_GPIO_initDigitalOutput(DIR_IOMUX);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PA5);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PB0);
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM_PB13,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_clearPins(GPIO0, PUL_PIN | DIR_PIN);
    DL_GPIO_setPins(ROJO_PORT, ROJO_PIN);      /* LEDs apagados (activo en bajo) */
    DL_GPIO_setPins(VERDE_PORT, VERDE_PIN);
    DL_GPIO_enableOutput(GPIO0, PUL_PIN | DIR_PIN | ROJO_PIN);
    DL_GPIO_enableOutput(GPIO1, VERDE_PIN);
}

static void uart_init(void)
{
    DL_UART_Config config = {
        .mode        = DL_UART_MODE_NORMAL,
        .direction   = DL_UART_DIRECTION_TX_RX,
        .flowControl = DL_UART_FLOW_CONTROL_NONE,
        .parity      = DL_UART_PARITY_NONE,
        .wordLength  = DL_UART_WORD_LENGTH_8_BITS,
        .stopBits    = DL_UART_STOP_BITS_ONE,
    };
    DL_UART_ClockConfig clock_config = {
        .clockSel    = DL_UART_CLOCK_BUSCLK,
        .divideRatio = DL_UART_CLOCK_DIVIDE_RATIO_1,
    };

    DL_GPIO_initPeripheralOutputFunction(IOMUX_PINCM_PA0, IOMUX_PA0_UC1_TX_SDA_PICO);
    DL_GPIO_initPeripheralInputFunction(IOMUX_PINCM_PA1, IOMUX_PA1_UC1_RX_SCL_SCLK);
    DL_UART_reset(UC1_INST_PTR);
    DL_UART_enablePower(UC1_INST_PTR);
    while (!DL_UART_isPowerEnabled(UC1_INST_PTR)) { }
    DL_UNICOMM_setIPMode(UC1_INST_PTR, DL_UNICOMM_UART);
    DL_UART_disable(UC1_INST_PTR);
    DL_UART_init(UC1_INST_PTR, &config);
    DL_UART_setClockConfig(UC1_INST_PTR, &clock_config);
    DL_UART_configBaudRate(UC1_INST_PTR, CPU_CLOCK_HZ, UART_BAUD);
    DL_UART_enable(UC1_INST_PTR);
}

/* -------------------------------------------------------------------------
 * 6. RELOJ: contador de ciclos del nucleo (DWT). 32 ciclos = 1 us.
 * ------------------------------------------------------------------------- */
#define DEMCR       (*(volatile uint32_t *)0xE000EDFCUL)
#define DWT_CTRL    (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT  (*(volatile uint32_t *)0xE0001004UL)

static void cronometro_init(void)
{
    DEMCR |= (1UL << 24);
    DWT_CYCCNT = 0UL;
    DWT_CTRL |= 1UL;
}

static void espera_us(uint32_t us)
{
    const uint32_t inicio = DWT_CYCCNT;
    const uint32_t ciclos = us * (CPU_CLOCK_HZ / 1000000UL);
    while ((DWT_CYCCNT - inicio) < ciclos) { }
}

/* -------------------------------------------------------------------------
 * 7. AYUDAS DE TEXTO POR UART
 * ------------------------------------------------------------------------- */
static void uart_putc(char c) { DL_UART_transmitDataBlocking(UC1_INST_PTR, (uint8_t)c); }
static void uart_puts(const char *s) { while (*s != '\0') uart_putc(*s++); }

static void uart_put_u32(uint32_t v)
{
    char d[10];
    uint32_t n = 0U;
    if (v == 0UL) { uart_putc('0'); return; }
    while (v != 0UL) { d[n++] = (char)('0' + (v % 10UL)); v /= 10UL; }
    while (n != 0U) uart_putc(d[--n]);
}

static void prompt(void) { uart_puts("\r\n> "); }

static bool igual(const char *a, const char *b)
{
    while ((*a != '\0') && (*b != '\0'))
    {
        char x = *a++, y = *b++;
        if ((x >= 'a') && (x <= 'z')) x = (char)(x - 32);
        if ((y >= 'a') && (y <= 'z')) y = (char)(y - 32);
        if (x != y) return false;
    }
    return (*a == '\0') && (*b == '\0');
}

static uint32_t partir(char *linea, char **pal, uint32_t max)
{
    uint32_t n = 0U;
    while ((*linea != '\0') && (n < max))
    {
        while (*linea == ' ') ++linea;
        if (*linea == '\0') break;
        pal[n++] = linea;
        while ((*linea != '\0') && (*linea != ' ')) ++linea;
        if (*linea != '\0') *linea++ = '\0';
    }
    return n;
}

/* Texto -> entero CON signo ("-300", "800"). false si no es un numero. */
static bool leer_entero_signo(const char *t, int32_t *v)
{
    bool neg = false, alguno = false;
    int32_t r = 0;
    if (*t == '-') { neg = true; ++t; }
    else if (*t == '+') { ++t; }
    while ((*t >= '0') && (*t <= '9')) { alguno = true; r = (r * 10) + (*t++ - '0'); }
    if (!alguno || (*t != '\0')) return false;
    *v = neg ? -r : r;
    return true;
}

/* -------------------------------------------------------------------------
 * 8. MOTOR: maquina de estados (ACELERANDO -> CRUCERO -> FRENANDO).
 *    avanzar_motor() da UN paso cada vez que se le llama, para que el
 *    "for(;;)" principal nunca se quede bloqueado y pueda seguir leyendo
 *    la UART y el boton mientras el motor gira.
 * ------------------------------------------------------------------------- */
static void leds_girando(bool girando)
{
    if (girando) { DL_GPIO_clearPins(VERDE_PORT, VERDE_PIN); DL_GPIO_setPins(ROJO_PORT, ROJO_PIN); }
    else         { DL_GPIO_setPins(VERDE_PORT, VERDE_PIN);   DL_GPIO_clearPins(ROJO_PORT, ROJO_PIN); }
}

static void poner_dir(bool horario)
{
    if (horario) DL_GPIO_setPins(DIR_PORT, DIR_PIN);
    else         DL_GPIO_clearPins(DIR_PORT, DIR_PIN);
    espera_us(DIR_SETUP_US);
    g_ahora_us += DIR_SETUP_US;
}

static void un_paso(uint32_t periodo_us)
{
    DL_GPIO_setPins(PUL_PORT, PUL_PIN);
    espera_us(PULSO_US);
    DL_GPIO_clearPins(PUL_PORT, PUL_PIN);
    espera_us(periodo_us - PULSO_US);
}

/* frecuencia en el paso "r" de una rampa de "larga" pasos */
static uint32_t frecuencia(uint32_t r, uint32_t larga, uint32_t f_max)
{
    if (larga == 0U) return f_max;
    return F_MIN_HZ + ((f_max - F_MIN_HZ) * r) / larga;
}

/* Arranca un movimiento. objetivo = 0 -> gira sin parar; objetivo = N
 * -> da exactamente N pasos y se frena solo. */
static void iniciar_run(bool horario, uint32_t objetivo)
{
    g_horario     = horario;
    g_objetivo    = objetivo;
    g_pasos_dados = 0U;
    g_rampa_usada = RAMPA_PASOS;
    if ((objetivo != 0U) && ((g_rampa_usada * 2U) > objetivo)) { g_rampa_usada = objetivo / 2U; }
    poner_dir(horario);
    g_r = 0U;
    g_estado = ACELERANDO;
    leds_girando(true);
}

/* Pide frenar (con rampa) desde donde este, sin importar el estado */
static void parar_run(void)
{
    if (g_estado != PARADO) { g_estado = FRENANDO; }
}

/* Pide invertir el sentido */
static void invertir_run(void)
{
    if (g_estado == PARADO) { g_horario = !g_horario; poner_dir(g_horario); }
    else                    { g_invertir = true; parar_run(); }
}

/* Da UN paso y actualiza la maquina de estados. Llamar seguido desde main(). */
static void avanzar_motor(void)
{
    if (g_estado == PARADO) { espera_us(1000); g_ahora_us += 1000U; return; }

    uint32_t periodo_us;
    if (g_estado == CRUCERO) { periodo_us = 1000000UL / g_vel_max; }
    else                     { periodo_us = 1000000UL / frecuencia(g_r, g_rampa_usada, g_vel_max); }

    un_paso(periodo_us);
    g_ahora_us += periodo_us;
    ++g_pasos_dados;

    if (g_estado == ACELERANDO)
    {
        if ((g_r + 1U) >= g_rampa_usada)
        {
            g_r = g_rampa_usada;
            if ((g_objetivo != 0U) && (g_pasos_dados >= (g_objetivo - g_rampa_usada))) { g_estado = FRENANDO; }
            else { g_estado = CRUCERO; }
        }
        else { ++g_r; }
    }
    else if (g_estado == CRUCERO)
    {
        if ((g_objetivo != 0U) && (g_pasos_dados >= (g_objetivo - g_rampa_usada)))
        {
            g_estado = FRENANDO;
            g_r = g_rampa_usada;
        }
    }
    else /* FRENANDO */
    {
        if (g_r > 0U) { --g_r; }
        if (g_r == 0U)
        {
            if (g_invertir)
            {
                g_invertir    = false;
                g_horario     = !g_horario;
                poner_dir(g_horario);
                g_objetivo    = 0U;
                g_pasos_dados = 0U;
                g_estado      = ACELERANDO;
            }
            else
            {
                g_estado = PARADO;
                leds_girando(false);
                uart_puts("\r\nOK detenido");
                if (g_objetivo != 0U) { uart_puts(", "); uart_put_u32(g_pasos_dados); uart_puts(" pasos"); }
                prompt();
            }
        }
    }
}

/* -------------------------------------------------------------------------
 * 9. COMANDOS POR UART
 * -------------------------------------------------------------------------
 */
static void cmd_arranca(void)
{
    if (g_estado != PARADO) { uart_puts("ERR ya esta girando. Usa PARA o GIRA"); return; }
    iniciar_run(g_horario, 0U);
    uart_puts("OK arrancando, sentido ");
    uart_puts(g_horario ? "HORARIO" : "ANTIHORARIO");
}

static void cmd_para(void)
{
    if (g_estado == PARADO) { uart_puts("ERR ya esta detenido"); return; }
    parar_run();
    uart_puts("OK frenando...");
}

static void cmd_gira(void)
{
    invertir_run();
    if (g_estado == PARADO)
    {
        uart_puts("OK sentido = "); uart_puts(g_horario ? "HORARIO" : "ANTIHORARIO");
        uart_puts(" (para la proxima vez que arranque)");
    }
    else { uart_puts("OK invirtiendo (frena, cambia y acelera)..."); }
}

static void cmd_pasos(char **pal, uint32_t n)
{
    int32_t pedidos;
    if (g_estado != PARADO) { uart_puts("ERR el motor ya esta girando. Manda PARA primero"); return; }
    if ((n != 2U) || !leer_entero_signo(pal[1], &pedidos) || (pedidos == 0))
    {
        uart_puts("ERR uso: PASOS <numero con signo, no 0>, ej. PASOS -300");
        return;
    }
    iniciar_run(pedidos >= 0, (uint32_t)((pedidos >= 0) ? pedidos : -pedidos));
    uart_puts("OK moviendo "); uart_put_u32(g_objetivo); uart_puts(" pasos ");
    uart_puts(g_horario ? "(horario)" : "(antihorario)");
}

static void cmd_vel(char **pal, uint32_t n)
{
    int32_t hz;
    if ((n != 2U) || !leer_entero_signo(pal[1], &hz) || (hz < (int32_t)F_MIN_HZ) || (hz > (int32_t)F_MAX_TOPE))
    {
        uart_puts("ERR uso: VEL <200-4000>");
        return;
    }
    g_vel_max = (uint32_t)hz;
    uart_puts("OK VEL="); uart_put_u32(g_vel_max); uart_puts(" Hz");
}

static void cmd_estado(void)
{
    switch (g_estado)
    {
        case PARADO:     uart_puts("DETENIDO"); break;
        case ACELERANDO: uart_puts("ACELERANDO"); break;
        case CRUCERO:    uart_puts("CRUCERO"); break;
        case FRENANDO:   uart_puts("FRENANDO"); break;
    }
    uart_puts(", sentido="); uart_puts(g_horario ? "HORARIO" : "ANTIHORARIO");
    uart_puts(", VEL="); uart_put_u32(g_vel_max); uart_puts(" Hz");
    if (g_objetivo != 0U) { uart_puts(", meta="); uart_put_u32(g_objetivo); uart_puts(" pasos"); }
}

static void ejecutar(char *linea)
{
    char *pal[PALABRAS_MAX];
    const uint32_t n = partir(linea, pal, PALABRAS_MAX);
    if (n == 0U) { prompt(); return; }

    if (igual(pal[0], "PING"))         { uart_puts("PONG __NOMBRE__"); }
    else if (igual(pal[0], "HELP"))    { uart_puts("ARRANCA | PARA | GIRA | VEL <hz> | PASOS <n> | ESTADO | PING | HELP"); }
    else if (igual(pal[0], "ARRANCA")) { cmd_arranca(); }
    else if (igual(pal[0], "PARA"))    { cmd_para(); }
    else if (igual(pal[0], "GIRA"))    { cmd_gira(); }
    else if (igual(pal[0], "PASOS"))   { cmd_pasos(pal, n); }
    else if (igual(pal[0], "VEL"))     { cmd_vel(pal, n); }
    else if (igual(pal[0], "ESTADO"))  { cmd_estado(); }
    else                                { uart_puts("ERR comando desconocido. Escriba HELP"); }
    prompt();
}

static void revisar_uart(void)
{
    uint8_t c;
    while (DL_UART_receiveDataCheck(UC1_INST_PTR, &c))
    {
        if ((c == '\r') || (c == '\n'))
        {
            if (g_largo != 0U)
            {
                g_linea[g_largo] = '\0';
                uart_puts("\r\n");
                ejecutar(g_linea);
                g_largo = 0U;
            }
        }
        else if (((c == '\b') || (c == 0x7F)) && (g_largo != 0U))
        {
            --g_largo;
            uart_puts("\b \b");
        }
        else if ((c >= 32U) && (c <= 126U) && (g_largo < (LINEA_MAX - 1U)))
        {
            g_linea[g_largo++] = (char)c;
            uart_putc((char)c);
        }
    }
}

/* -------------------------------------------------------------------------
 * 10. BOTON FISICO PB13: antirrebote, corta = arranca/para, larga = invierte
 * ------------------------------------------------------------------------- */
static void revisar_boton(void)
{
    static bool     crudo = false, estable = false, largo_hecho = false;
    static uint32_t cambio_us = 0U, presion_us = 0U;

    const bool c = (DL_GPIO_readPins(BOTON_PORT, BOTON_PIN) == 0UL);
    if (c != crudo) { crudo = c; cambio_us = g_ahora_us; }
    if ((estable != crudo) && ((g_ahora_us - cambio_us) >= ANTIRREBOTE_US))
    {
        estable = crudo;
        if (estable) { presion_us = g_ahora_us; largo_hecho = false; }
        else if (!largo_hecho)
        {
            if (g_estado == PARADO) { iniciar_run(g_horario, 0U); uart_puts("\r\nOK arranca (boton)"); }
            else                    { parar_run(); uart_puts("\r\nOK frenando (boton)"); }
            prompt();
        }
    }
    if (estable && !largo_hecho && ((g_ahora_us - presion_us) >= LARGO_US))
    {
        largo_hecho = true;
        invertir_run();
        uart_puts("\r\nOK invierte (boton)");
        prompt();
    }
}

/* -------------------------------------------------------------------------
 * 11. MAIN
 * ------------------------------------------------------------------------- */
int main(void)
{
    gpio_init();
    uart_init();
    cronometro_init();
    leds_girando(false);

    uart_puts("\r\n__NOMBRE__ LISTO (SRAM). Escriba HELP");
    prompt();

    for (;;)
    {
        revisar_uart();
        revisar_boton();
        avanzar_motor();
    }
}
