/*
 * ==========================================================================
 *  Proyecto: __NOMBRE__   (SRAM: la flash NO se toca)
 *  Motor paso a paso con driver STEPPERONLINE CL86T (modo PUL/DIR)
 *  VERSION 1: busy-wait (la CPU espera contando ciclos)
 *
 *  Conexion (ver LEEME_CONEXION.txt):
 *    PA3  -> PUL  (a traves del transistor / buffer a 5 V)
 *    PA27 -> DIR  (igual)
 *    PB13 = boton WAKE   PA5 = LED rojo   PB0 = LED verde
 *
 *  Que hace:
 *    - WAKE corto  = arrancar / detener (con rampa).
 *    - WAKE largo (>= 800 ms) = invertir giro (si gira: frena, invierte y acelera).
 *    - Rampa 200 Hz -> 2 kHz en 800 pasos. Pulso de 10 us. DIR 20 us antes.
 *    - LED verde = girando, LED rojo = detenido.
 *
 *  Este proyecto NO usa SysConfig: la seccion 5 hace a mano lo mismo que
 *  SYSCFG_DL_init() generaria (mismas funciones DL_GPIO_...). Asi ves que
 *  hay detras de cada casilla de SysConfig.
 * ==========================================================================
 */

/* -------------------------------------------------------------------------
 * 1. INCLUDES
 * ------------------------------------------------------------------------- */
#include <stdbool.h>
#include <stdint.h>

#include "hw/soc.h"     /* registros y nombres de pines (IOMUX_PINCM_PA3...) */
#include "dl_gpio.h"    /* DL_GPIO_... (las mismas que usa SysConfig) */

/* -------------------------------------------------------------------------
 * 2. PINES  (puerto + bit)
 * ------------------------------------------------------------------------- */
#define CPU_CLOCK_HZ    (32000000UL)       /* reloj por defecto, sin PLL */

#define PUL_PORT        GPIO0              /* PA3  */
#define PUL_PIN         DL_GPIO_PIN(3)
#define PUL_IOMUX       IOMUX_PINCM_PA3
#define DIR_PORT        GPIO0              /* PA27 */
#define DIR_PIN         DL_GPIO_PIN(27)
#define DIR_IOMUX       IOMUX_PINCM_PA27
#define ROJO_PORT       GPIO0              /* PA5, activo en bajo */
#define ROJO_PIN        DL_GPIO_PIN(5)
#define VERDE_PORT      GPIO1              /* PB0, activo en bajo */
#define VERDE_PIN       DL_GPIO_PIN(0)
#define BOTON_PORT      GPIO1              /* PB13 WAKE: 0 = presionado */
#define BOTON_PIN       DL_GPIO_PIN(13)

/* -------------------------------------------------------------------------
 * 3. PARAMETROS DEL MOVIMIENTO
 * ------------------------------------------------------------------------- */
#define F_MIN_HZ        200U     /* arranque y paro                           */
#define F_MAX_HZ        2000U    /* crucero: 75 rpm con 1600 pulsos/vuelta    */
#define RAMPA_PASOS     800U     /* pasos para ir de F_MIN a F_MAX            */
#define PULSO_US        10U      /* el CL86T pide >= 1 us; tu pediste >= 5 us */
#define DIR_SETUP_US    20U      /* el CL86T pide >= 2 us; tu pediste >= 10 us */

#define ANTIRREBOTE_US  20000U   /* 20 ms  */
#define LARGO_US        800000U  /* 800 ms = pulsacion larga */
#define TICK_PARADO_US  1000U    /* parado: revisar el boton cada 1 ms */

typedef enum { PARADO, ACELERANDO, CRUCERO, FRENANDO } Estado;

/* Variables globales para verlas en CCS (View > Expressions) */
volatile Estado   g_estado;
volatile uint32_t g_frecuencia_hz;
volatile uint32_t g_pasos;

/* -------------------------------------------------------------------------
 * 4. ARRANQUE: lo llama Reset_Handler (arranque_ccs.c) antes de main
 * ------------------------------------------------------------------------- */
void SystemInit(void)
{
    (*(volatile uint32_t *)0xE000ED88UL) = 0x00F00003UL;  /* CPACR: FPU + TMU */
    (*(volatile uint32_t *)0xE000ED08UL) = 0x20000000UL;  /* VTOR: vectores en SRAM */
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

/* -------------------------------------------------------------------------
 * 5. "SYSCONFIG A MANO": lo mismo que generaria SYSCFG_DL_GPIO_init()
 * ------------------------------------------------------------------------- */
static void gpio_init(void)
{
    /* a) reset y encender los puertos A y B (SysConfig: SYSCFG_DL_initPower) */
    DL_GPIO_reset(GPIO0);
    DL_GPIO_reset(GPIO1);
    DL_GPIO_enablePower(GPIO0);
    DL_GPIO_enablePower(GPIO1);
    while (!DL_GPIO_isPowerEnabled(GPIO0) || !DL_GPIO_isPowerEnabled(GPIO1)) { }

    /* b) IOMUX: cada pin se conecta al GPIO (funcion 1).
     *    Casilla "Direction: Output" sin extras -> DL_GPIO_initDigitalOutput.
     *    Drive Strength se queda LOW: PA3/PA27 son pines SDL y no tienen HIGH. */
    DL_GPIO_initDigitalOutput(PUL_IOMUX);
    DL_GPIO_initDigitalOutput(DIR_IOMUX);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PA5);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PB0);

    /* Casilla "Input + Pull-Up" -> DL_GPIO_initDigitalInputFeatures */
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM_PB13,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP, DL_GPIO_WAKEUP_DISABLE);

    /* c) "Initial Value": primero el valor, despues habilitar la salida,
     *    asi el pin nunca muestra un valor equivocado. */
    DL_GPIO_clearPins(GPIO0, PUL_PIN | DIR_PIN);          /* Cleared */
    DL_GPIO_setPins(ROJO_PORT, ROJO_PIN);                  /* Set = LED apagado */
    DL_GPIO_setPins(VERDE_PORT, VERDE_PIN);
    DL_GPIO_enableOutput(GPIO0, PUL_PIN | DIR_PIN | ROJO_PIN);
    DL_GPIO_enableOutput(GPIO1, VERDE_PIN);
}

/* -------------------------------------------------------------------------
 * 6. RELOJ: contador de ciclos del nucleo (DWT). 32 ciclos = 1 us.
 * ------------------------------------------------------------------------- */
#define DEMCR       (*(volatile uint32_t *)0xE000EDFCUL)
#define DWT_CTRL    (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT  (*(volatile uint32_t *)0xE0001004UL)

static void cronometro_init(void)
{
    DEMCR |= (1UL << 24);
    DWT_CYCCNT = 0UL;
    DWT_CTRL |= 1UL;
}

/* Busy-wait: la CPU da vueltas aqui hasta que pasan "us" microsegundos */
static void espera_us(uint32_t us)
{
    const uint32_t inicio = DWT_CYCCNT;
    const uint32_t ciclos = us * (CPU_CLOCK_HZ / 1000000UL);
    while ((DWT_CYCCNT - inicio) < ciclos) { }
}

/* -------------------------------------------------------------------------
 * 7. AYUDAS DEL MOTOR
 * ------------------------------------------------------------------------- */
static uint32_t frecuencia(uint32_t r)          /* r = 0..RAMPA_PASOS */
{
    return F_MIN_HZ + ((F_MAX_HZ - F_MIN_HZ) * r) / RAMPA_PASOS;
}

static void leds(bool girando)
{
    if (girando) {
        DL_GPIO_clearPins(VERDE_PORT, VERDE_PIN);   /* verde ON */
        DL_GPIO_setPins(ROJO_PORT, ROJO_PIN);       /* rojo OFF */
    } else {
        DL_GPIO_setPins(VERDE_PORT, VERDE_PIN);
        DL_GPIO_clearPins(ROJO_PORT, ROJO_PIN);
    }
}

static void poner_dir(bool horario)
{
    if (horario) DL_GPIO_setPins(DIR_PORT, DIR_PIN);
    else         DL_GPIO_clearPins(DIR_PORT, DIR_PIN);
    espera_us(DIR_SETUP_US);                    /* DIR estable antes del pulso */
}

/* Un paso: PUL arriba PULSO_US y abajo el resto del periodo */
static void un_paso(uint32_t periodo_us)
{
    DL_GPIO_setPins(PUL_PORT, PUL_PIN);
    espera_us(PULSO_US);
    DL_GPIO_clearPins(PUL_PORT, PUL_PIN);
    espera_us(periodo_us - PULSO_US);
    g_pasos++;
}

static bool boton_crudo(void)
{
    return DL_GPIO_readPins(BOTON_PORT, BOTON_PIN) == 0UL;
}

/* -------------------------------------------------------------------------
 * 8. MAIN
 * ------------------------------------------------------------------------- */
int main(void)
{
    gpio_init();
    cronometro_init();

    Estado   estado   = PARADO;
    uint32_t r        = 0U;          /* posicion en la rampa */
    bool     horario  = true;
    bool     invertir = false;
    uint32_t ahora_us = 0U;          /* suma de lo que hemos esperado */

    bool     crudo = false, estable = false, largo_hecho = false;
    uint32_t cambio_us = 0U, presion_us = 0U;

    poner_dir(horario);
    leds(false);

    for (;;)
    {
        /* ---------- A) un paso, o esperar 1 ms si esta parado ---------- */
        if (estado == PARADO) {
            espera_us(TICK_PARADO_US);
            ahora_us += TICK_PARADO_US;
            g_frecuencia_hz = 0U;
        } else {
            const uint32_t f = frecuencia(r);
            const uint32_t periodo = 1000000UL / f;   /* 200 Hz = 5000 us; 2 kHz = 500 us */
            g_frecuencia_hz = f;
            un_paso(periodo);
            ahora_us += periodo;

            if (estado == ACELERANDO) {
                if (++r >= RAMPA_PASOS) { r = RAMPA_PASOS; estado = CRUCERO; }
            } else if (estado == FRENANDO) {
                if (r > 0U) { --r; }
                if (r == 0U) {
                    if (invertir) {                 /* frenar -> invertir -> acelerar */
                        invertir = false;
                        horario = !horario;
                        poner_dir(horario);
                        ahora_us += DIR_SETUP_US;
                        estado = ACELERANDO;
                    } else {
                        estado = PARADO;
                        leds(false);
                    }
                }
            }
        }
        g_estado = estado;

        /* ---------- B) boton: antirrebote, corta / larga ---------- */
        const bool c = boton_crudo();
        if (c != crudo) { crudo = c; cambio_us = ahora_us; }
        if ((estable != crudo) && ((ahora_us - cambio_us) >= ANTIRREBOTE_US)) {
            estable = crudo;
            if (estable) {                       /* se acaba de presionar */
                presion_us = ahora_us;
                largo_hecho = false;
            } else if (!largo_hecho) {           /* se solto antes de 800 ms: CORTA */
                if (estado == PARADO) {
                    r = 0U;
                    poner_dir(horario);
                    estado = ACELERANDO;
                    leds(true);
                } else {
                    invertir = false;
                    estado = FRENANDO;
                }
            }
        }
        if (estable && !largo_hecho && ((ahora_us - presion_us) >= LARGO_US)) {
            largo_hecho = true;                  /* LARGA: invertir */
            if (estado == PARADO) {
                horario = !horario;
                poner_dir(horario);
            } else {
                invertir = true;
                estado = FRENANDO;
            }
        }
        /* >>> AQUI: con busy-wait, lo que pongas aqui RETRASA los pasos.
         *     Por eso existe la version con timer (sram_motor_timer). */
    }
}
