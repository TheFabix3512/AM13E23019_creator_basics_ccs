/*
 * linker_flash_ccs.cmd  -  AM13E23019, programa en FLASH (banco 0) y variables en SRAM.
 * No hay regiones NONMAIN (0x601xxxxx): la configuracion de arranque de la placa no se toca.
 */
-uinterruptVectors
--stack_size=0x1000
--heap_size=0x400

MEMORY
{
    FLASH_BANK0 : ORIGIN = 0x00000000, LENGTH = 0x00040000   /* 256 KB banco 0 */
    SRAM        : ORIGIN = 0x20000000, LENGTH = 0x00018000   /* 96 KB          */
}

SECTIONS
{
    .intvecs    : > 0x00000000             /* tabla de vectores: el chip arranca aqui */
    .text       : > FLASH_BANK0, palign(8)
    .rodata     : > FLASH_BANK0, palign(8)
    .cinit      : > FLASH_BANK0, palign(8)
    .binit      : > FLASH_BANK0, palign(8)
    .init_array : > FLASH_BANK0, palign(8)
    .data       : > SRAM
    .bss        : > SRAM
    .sysmem     : > SRAM
    .stack      : > SRAM
    .vtable     : > SRAM
}
