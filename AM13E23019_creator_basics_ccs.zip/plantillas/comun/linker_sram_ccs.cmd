/*
 * linker_sram_ccs.cmd  -  AM13E23019, TODO en SRAM (equivalente al .sct de Keil).
 * No existe ninguna region de flash: el linker no PUEDE poner nada ahi.
 */
-uinterruptVectors
--stack_size=0x1000
--heap_size=0x1000

MEMORY
{
    SRAM_CODE : ORIGIN = 0x20000000, LENGTH = 0x00010000   /* 64 KB codigo y constantes */
    SRAM_DATA : ORIGIN = 0x20010000, LENGTH = 0x00008000   /* 32 KB variables y pila    */
}

SECTIONS
{
    .intvecs    : > 0x20000000             /* tabla de vectores al inicio (VTOR) */
    .text       : > SRAM_CODE, palign(8)
    .rodata     : > SRAM_CODE, palign(8)
    .cinit      : > SRAM_CODE, palign(8)
    .binit      : > SRAM_CODE, palign(8)
    .init_array : > SRAM_CODE
    .data       : > SRAM_DATA
    .bss        : > SRAM_DATA
    .sysmem     : > SRAM_DATA
    .stack      : > SRAM_DATA
    .vtable     : > SRAM_DATA
}
