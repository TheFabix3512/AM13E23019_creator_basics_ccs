# Se ejecuta SOLO despues de cada compilacion (paso post-build de CCS).
# Revisa las direcciones del .out y, si algo esta fuera de lugar, hace FALLAR la compilacion
# para que CCS no deje cargarlo.
#   -Modo sram  : todo debe estar en SRAM (0x20000000-0x20017FFF). Cargarlo no toca la flash.
#   -Modo flash : solo flash banco 0 (0x0-0x3FFFF) y SRAM. Nada en NONMAIN.
param([Parameter(Mandatory = $true)][string]$Imagen, [ValidateSet('sram', 'flash')][string]$Modo = 'sram')
$ErrorActionPreference = 'Stop'
try {
    $b = [IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $Imagen))
    $phoff = [BitConverter]::ToUInt32($b, 0x1C); $phent = [BitConverter]::ToUInt16($b, 0x2A); $phnum = [BitConverter]::ToUInt16($b, 0x2C)
    $n = 0; $vectores = $false
    for ($i = 0; $i -lt $phnum; $i++) {
        $o = $phoff + $i * $phent
        if ([BitConverter]::ToUInt32($b, $o) -ne 1) { continue }
        $memsz = [BitConverter]::ToUInt32($b, $o + 20); if ($memsz -eq 0) { continue }
        foreach ($a in @([BitConverter]::ToUInt32($b, $o + 8), [BitConverter]::ToUInt32($b, $o + 12))) {
            $fin = [uint64]$a + $memsz
            $enSram = ($a -ge 0x20000000) -and ($fin -le 0x20018000)
            $enFlash = ($fin -le 0x40000)
            if ($a -eq 0) { $vectores = $true }
            if (-not ($enSram -or ($Modo -eq 'flash' -and $enFlash))) {
                throw ('segmento fuera de lo permitido para modo {0}: 0x{1:X8} ({2} bytes)' -f $Modo, $a, $memsz)
            }
        }
        $n++
    }
    if ($n -eq 0) { throw 'no hay segmentos cargables' }
    if ($Modo -eq 'flash' -and -not $vectores) { throw 'la tabla de vectores no quedo en 0x00000000' }
    Write-Output "VERIFICACION OK ($Modo): $n segmento(s) en lugares permitidos."
    exit 0
}
catch {
    Write-Output "VERIFICACION FALLO: $($_.Exception.Message)"
    exit 1
}
