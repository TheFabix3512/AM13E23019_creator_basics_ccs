$ErrorActionPreference = 'Stop'

# Consola sencilla para hablar con el laboratorio por la UART del XDS110.
# Escribe un comando, presiona Enter y espera la respuesta. "salir" termina.

$uart = Get-CimInstance Win32_SerialPort |
    Where-Object { $_.Name -match 'Application/User UART' } |
    Select-Object -First 1
if ($null -eq $uart) {
    Write-Host 'No encontre el puerto "XDS110 Class Application/User UART".' -ForegroundColor Red
    Write-Host 'Revisa que la LaunchPad este conectada por USB.'
    Read-Host 'Presiona Enter para cerrar'
    exit 1
}

$port = [System.IO.Ports.SerialPort]::new($uart.DeviceID, 115200, 'None', 8, 'One')
$port.Handshake = 'None'
$port.ReadTimeout = 200

function Read-Reply([int]$timeoutMs) {
    $buffer = ''
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    while ($watch.ElapsedMilliseconds -lt $timeoutMs) {
        if ($port.BytesToRead -gt 0) {
            $buffer += $port.ReadExisting()
            if ($buffer.TrimEnd().EndsWith('>')) { break }
        } else {
            Start-Sleep -Milliseconds 10
        }
    }
    return $buffer
}

try {
    $port.Open()
    Write-Host ''
    Write-Host "Conectado a $($uart.DeviceID) - $($uart.Name)" -ForegroundColor Green
    Write-Host 'Configuracion: 115200 baudios, 8 bits, sin paridad, 1 stop (115200 8N1)'
    Write-Host 'Prueba: PING, HELP, INFO, ID, MATH SIN 1.0 ... Escribe "salir" para terminar.'
    Write-Host ''
    $port.DiscardInBuffer()
    $port.Write("`r")
    $first = Read-Reply 800
    if ($first.Trim() -eq '') { Write-Host '> ' -NoNewline } else { Write-Host $first -NoNewline }

    while ($true) {
        $line = Read-Host
        if ($line -eq 'salir') { break }
        if ($line.Trim() -eq '') { Write-Host '> ' -NoNewline; continue }
        foreach ($character in "$line`r".ToCharArray()) {
            $port.Write([string]$character)
            Start-Sleep -Milliseconds 2
        }
        $reply = Read-Reply 8000
        if ($reply -eq '') {
            Write-Host '(sin respuesta: el laboratorio no esta cargado o la tarjeta se reinicio)' -ForegroundColor Yellow
            Write-Host '> ' -NoNewline
            continue
        }
        # El chip repite lo que escribiste en la primera linea; se omite para no verlo doble.
        $lines = $reply -split "`r`n", 2
        if ($lines.Count -eq 2 -and $lines[0].Trim() -eq $line.Trim()) { $reply = $lines[1] }
        Write-Host $reply -NoNewline
    }
}
finally {
    if ($port.IsOpen) { $port.Close() }
    $port.Dispose()
    Write-Host ''
    Write-Host 'Puerto cerrado. El laboratorio sigue en SRAM hasta que presiones nRST.'
}
