/*
 * arranque_ccs.c  -  arranque para compilar con CCS (TI Arm Clang) y correr en SRAM.
 *
 * El startup del SDK (startup_ti_arm_clang.c) trae un Reset_Handler "debil" que
 * salta directo a _c_int00 y NUNCA llama a SystemInit. Este Reset_Handler fuerte
 * lo reemplaza y hace lo mismo que en Keil:
 *   1) poner la pila (MSP) al final de .stack
 *   2) SystemInit()  -> CPACR (FPU + TMU) y VTOR = 0x20000000 (esta en main.c)
 *   3) saltar a _c_int00 (copia .data, limpia .bss y llama a main)
 * El proyecto enlaza con --entry_point=Reset_Handler para que el depurador
 * arranque aqui al cargar el programa.
 */
__attribute__((naked, noreturn)) void Reset_Handler(void)
{
    __asm volatile(
        "movw r0, #:lower16:__STACK_END \n"
        "movt r0, #:upper16:__STACK_END \n"
        "msr  msp, r0                   \n"
        "bl   SystemInit                \n"
        "b    _c_int00                  \n");
}
