@echo off
rem Solo abre la consola UART (no compila ni carga). Sirve mientras CCS depura.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0herramientas\CONSOLA_UART.ps1"
