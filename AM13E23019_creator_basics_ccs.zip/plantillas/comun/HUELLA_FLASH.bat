@echo off
rem Lee la flash, guarda respaldo y dice si cambio. (.bat y no .cmd: CCS toma los .cmd como archivos del linker)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0herramientas\HUELLA_FLASH.ps1"
pause
