# Lee TODA la flash (solo lectura), guarda un respaldo y dice si cambio desde la ultima vez.
# Usalo ANTES de grabar un proyecto de flash (respaldo) y DESPUES de depurar uno de SRAM (comprobar).
$ErrorActionPreference = 'Stop'
$proy = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$ws = Split-Path -Parent $proy
$dslite = 'C:\ti\ccs2101\ccs\ccs_base\DebugServer\bin\DSLite.exe'
$ccxml = Join-Path $proy 'targetConfigs\AM13E23019.ccxml'
$dir = Join-Path $ws 'respaldos_flash'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$tmp = Join-Path $dir 'lectura.bin'
Write-Host 'Leyendo la flash (unos 20 s)... cierra antes la depuracion de CCS.'
& $dslite memory "--config=$ccxml" '--range=0x0,0x7FF00' "--output=$tmp" '--timeout=60' | Out-Null
if (-not (Test-Path $tmp)) { throw 'No se pudo leer la flash (esta CCS depurando?).' }
$h = (Get-FileHash $tmp).Hash
$ultima = Join-Path $dir 'ultima_huella.txt'
$antes = if (Test-Path $ultima) { (Get-Content $ultima -First 1).Trim() } else { '' }
Write-Host "Huella actual:   $h"
if ($antes -eq '') { Write-Host 'Primera lectura: se guarda como referencia.' }
elseif ($antes -eq $h) { Write-Host "Huella anterior: $antes" ; Write-Host 'FLASH IGUAL QUE LA ULTIMA VEZ' -ForegroundColor Green }
else { Write-Host "Huella anterior: $antes"; Write-Host 'LA FLASH CAMBIO desde la ultima lectura' -ForegroundColor Yellow }
if ($antes -ne $h) {
    $copia = Join-Path $dir ('flash_{0}.bin' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    Copy-Item $tmp $copia
    Set-Content $ultima $h
    Write-Host "Respaldo guardado: $copia"
}
Remove-Item $tmp
& 'C:\ti\ccs2101\ccs\ccs_base\scripting\bin\dss.bat' (Join-Path $proy 'herramientas\REINICIAR.js') | Out-Null
Write-Host 'La placa se reinicio y corre lo que tenga la flash.'
