importPackage(Packages.com.ti.debug.engine.scripting);
importPackage(Packages.com.ti.ccstudio.scripting.environment);
// Reinicio por hardware: arranca el programa de la flash. No borra ni programa nada.
var env = ScriptingEnvironment.instance();
var server = env.getServer("DebugServer.1");
server.setConfig("__RUTA__/targetConfigs/AM13E23019.ccxml");
var session = server.openSession(".*CORTEX_M33.*");
session.target.connect();
session.target.reset();
session.target.runAsynch();
java.lang.Thread.sleep(500);
session.target.disconnect();
server.stop();
