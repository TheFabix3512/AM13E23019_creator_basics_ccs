/*
 * ==========================================================================
 *  Proyecto: __NOMBRE__   (se GRABA EN FLASH: sobrevive a un reset)
 *  Base GPIO para LP-AM13E230 (AM13E23019). Sin DriverLib: solo registros
 *  con los nombres de hw/soc.h del SDK.
 *
 *  Que hace:
 *    - El LED rojo (PA5) parpadea.
 *    - Boton BOOT/BSL (PA6 en tarjeta E2, PA3 en E1): cambia entre LED rojo y verde.
 *    - Boton WAKE (PB13): cambia la velocidad del parpadeo (lento / rapido).
 *
 *  Para practicar busca ">>> AQUI".
 * ==========================================================================
 */

/* -------------------------------------------------------------------------
 * 1. INCLUDES
 * ------------------------------------------------------------------------- */
#include <stdbool.h>
#include <stdint.h>

#include "hw/soc.h"   /* nombres y direcciones de los registros (GPIO0, IOMUX...) */

/* -------------------------------------------------------------------------
 * 2. CONFIGURACION
 * ------------------------------------------------------------------------- */
#define CPU_CLOCK_HZ        (32000000UL)    /* reloj por defecto, sin PLL */

#define LED_ROJO            (1UL << 5)      /* PA5 = GPIO0 pin 5, activo en bajo */
#define LED_VERDE           (1UL << 0)      /* PB0 = GPIO1 pin 0, activo en bajo */
#define BOTON_BOOT_E2       (1UL << 6)      /* PA6: 1 al presionar */
#define BOTON_BOOT_E1       (1UL << 3)      /* PA3: tarjetas revision E1 */
#define BOTON_WAKE          (1UL << 13)     /* PB13: 0 al presionar */

#define PIN_GPIO            (0x00000001UL)  /* funcion 1 del IOMUX = GPIO */
#define PIN_SALIDA          (IOMUX_PINCM_PC_CONNECTED | PIN_GPIO)
#define PIN_ENTRADA_PULLUP  (IOMUX_PINCM_INENA_ENABLE | IOMUX_PINCM_PIPU_ENABLE | PIN_GPIO)
#define PIN_ENTRADA_PULLDN  (IOMUX_PINCM_INENA_ENABLE | IOMUX_PINCM_PIPD_ENABLE | PIN_GPIO)

#define ANTIRREBOTE_MS      (20UL)          /* el boton debe quedarse quieto 20 ms */
#define PARPADEO_LENTO_MS   (500UL)
#define PARPADEO_RAPIDO_MS  (100UL)

/* Contador de ciclos del nucleo (el "cronometro") */
#define DEMCR               (*(volatile uint32_t *)0xE000EDFCUL)
#define DWT_CTRL            (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT          (*(volatile uint32_t *)0xE0001004UL)

/* -------------------------------------------------------------------------
 * 3. TIPOS
 * ------------------------------------------------------------------------- */
typedef struct
{
    bool crudo;        /* lo que lee el pin ahora (puede rebotar) */
    bool estable;      /* valor confirmado */
    uint32_t desde;    /* milisegundo del ultimo cambio */
} Boton;

/* -------------------------------------------------------------------------
 * 4. ARRANQUE: Reset_Handler llama a SystemInit antes de main.
 *    En flash los vectores ya estan en 0x00000000, no hay que mover VTOR.
 * ------------------------------------------------------------------------- */
void SystemInit(void)
{
    (*(volatile uint32_t *)0xE000ED88UL) = 0x00F00003UL;  /* CPACR: FPU + TMU */
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

/* -------------------------------------------------------------------------
 * 5. INICIALIZACION: reset -> encender -> esperar -> pines
 * ------------------------------------------------------------------------- */
static void gpio_encender(GPIO_Regs *gpio)
{
    gpio->GPRCM.RSTCTL = GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETSTKYCLR_CLR | GPIO_RSTCTL_RESETASSERT_ASSERT;
    gpio->GPRCM.PWREN  = GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE;
}

static void gpio_init(void)
{
    gpio_encender(GPIO0);                 /* puerto A */
    gpio_encender(GPIO1);                 /* puerto B */
    for (volatile uint32_t i = 0; i < 64UL; ++i) { }

    /* LEDs: salidas, empiezan apagados (1 = apagado) */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PA5] = PIN_SALIDA;
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PB0] = PIN_SALIDA;
    GPIO0->DOUTSET31_0 = LED_ROJO;
    GPIO1->DOUTSET31_0 = LED_VERDE;
    GPIO0->DOESET31_0  = LED_ROJO;
    GPIO1->DOESET31_0  = LED_VERDE;

    /* Botones: entradas con resistencia interna */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PA6]  = PIN_ENTRADA_PULLDN;   /* BOOT (E2) */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PA3]  = PIN_ENTRADA_PULLDN;   /* BOOT (E1) */
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PB13] = PIN_ENTRADA_PULLUP;   /* WAKE */
}

static void cronometro_init(void)
{
    DEMCR |= (1UL << 24);    /* habilitar el bloque DWT */
    DWT_CYCCNT = 0UL;
    DWT_CTRL |= 1UL;         /* empezar a contar ciclos */
}

/* -------------------------------------------------------------------------
 * 6. FUNCIONES DE AYUDA
 * ------------------------------------------------------------------------- */
static void led(uint32_t cual, bool encendido)
{
    GPIO0->DOUTSET31_0 = LED_ROJO;                  /* apagar los dos */
    GPIO1->DOUTSET31_0 = LED_VERDE;
    if (!encendido) return;
    if (cual == 0U) GPIO0->DOUTCLR31_0 = LED_ROJO;  /* 0 = encendido */
    else            GPIO1->DOUTCLR31_0 = LED_VERDE;
}

static bool leer_boot(void)
{
    return (GPIO0->DIN31_0 & (BOTON_BOOT_E2 | BOTON_BOOT_E1)) != 0UL;
}

static bool leer_wake(void)
{
    return (GPIO1->DIN31_0 & BOTON_WAKE) == 0UL;   /* activo en bajo */
}

/* Antirrebote: true solo en el momento en que se confirma una pulsacion */
static bool boton_presionado(Boton *b, bool crudo, uint32_t ahora)
{
    if (crudo != b->crudo)
    {
        b->crudo = crudo;
        b->desde = ahora;
    }
    else if ((b->estable != crudo) && ((uint32_t)(ahora - b->desde) >= ANTIRREBOTE_MS))
    {
        b->estable = crudo;
        return crudo;
    }
    return false;
}

/* -------------------------------------------------------------------------
 * 7. MAIN: inicializar y repetir para siempre; todo se revisa cada 1 ms
 * ------------------------------------------------------------------------- */
int main(void)
{
    Boton boot = {false, false, 0UL};
    Boton wake = {false, false, 0UL};
    uint32_t led_activo = 0U;                  /* 0 = rojo, 1 = verde */
    uint32_t periodo = PARPADEO_LENTO_MS;
    uint32_t ahora = 0UL;                      /* milisegundos desde el arranque */
    uint32_t siguiente_cambio = 0UL;
    bool encendido = false;

    gpio_init();
    cronometro_init();
    uint32_t siguiente_tick = DWT_CYCCNT + (CPU_CLOCK_HZ / 1000UL);

    for (;;)
    {
        /* Esperar al siguiente milisegundo */
        if ((int32_t)(DWT_CYCCNT - siguiente_tick) < 0)
        {
            continue;
        }
        siguiente_tick += (CPU_CLOCK_HZ / 1000UL);
        ++ahora;

        /* BOOT: cambiar de LED */
        if (boton_presionado(&boot, leer_boot(), ahora))
        {
            led_activo ^= 1U;
        }

        /* WAKE: cambiar velocidad */
        if (boton_presionado(&wake, leer_wake(), ahora))
        {
            periodo = (periodo == PARPADEO_LENTO_MS) ? PARPADEO_RAPIDO_MS : PARPADEO_LENTO_MS;
        }

        /* Parpadeo: invertir el LED cada "periodo" ms */
        if ((int32_t)(ahora - siguiente_cambio) >= 0)
        {
            encendido = !encendido;
            led(led_activo, encendido);
            siguiente_cambio = ahora + periodo;
        }

        /* >>> AQUI: agrega lo que quieras revisar cada milisegundo */
    }
}
