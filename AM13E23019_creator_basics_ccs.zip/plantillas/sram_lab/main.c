/*
 * Laboratorio AM13E230 v2 - monitor temporal en SRAM para LP-AM13E230.
 *
 * Se carga por XDS110 directamente en SRAM: NO programa ni borra la flash.
 * Un nRST o desconectar la tarjeta devuelve el control al programa de flash.
 *
 * Consola: XDS110 Application/User UART (UC1: PA0 TX, PA1 RX), 115200 8N1.
 *
 * Que se puede aprender con este monitor:
 *   1. Preguntarle cosas al chip: INFO, ID, PEEK (lectura de memoria/registros).
 *   2. Delegar trabajo en los "ayudantes" del Cortex-M33:
 *        TMU  -> coprocesador matematico (sin, cos, atan, sqrt, exp, ln, div)
 *        CRCP -> motor de CRC por hardware
 *        AES  -> motor criptografico AES-128/256
 *        DMA  -> copia memoria mientras la CPU hace otra cosa
 *   3. Comparar CPU contra hardware con datos identicos y medir ciclos (DWT).
 *   4. Diagnosticar fallos: HardFault_Handler imprime CFSR/HFSR/PC por UART.
 */

#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#include "hw/soc.h"
#include "dl_gpio.h"
#include "dl_unicomm.h"
#include "dl_unicommuart.h"
#include "dl_crcp.h"
#include "dl_aes.h"
#include "dl_dma.h"
#include "dl_factoryregion.h"
#include "arm_cde.h"

/*
 * Keil MDK-Lite limita la imagen a 32 KB de codigo. Todo lo que no se mide
 * (consola, parser, impresion) se compila optimizado por tamano; las rutinas
 * que se miden (TMU, benchmarks, CRC, DMA) se compilan optimizadas por
 * velocidad, sin desenrollar bucles para que CPU y TMU se comparen igual.
 */
#pragma clang attribute push (__attribute__((minsize)), apply_to = function)

/* ------------------------------------------------------------------------ */
/* Configuracion                                                            */
/* ------------------------------------------------------------------------ */

#define LAB_VERSION               "__NOMBRE__"
#define CPU_CLOCK_HZ              (32000000UL)   /* reloj por defecto, sin PLL */
#define UART_BAUD                 (115200UL)

#define LED_RED_MASK              (1UL << 5)
#define LED_GREEN_MASK            (1UL << 0)
#define BUTTON_BOOT_E2_MASK       (1UL << 6)
#define BUTTON_BOOT_E1_MASK       (1UL << 3)
#define BUTTON_WAKE_MASK          (1UL << 13)

#define GPIO_FUNCTION             (0x00000001UL)
#define PIN_OUTPUT_CONNECTED      (IOMUX_PINCM_PC_CONNECTED | GPIO_FUNCTION)
#define PIN_INPUT_PULLUP          (IOMUX_PINCM_INENA_ENABLE | IOMUX_PINCM_PIPU_ENABLE | GPIO_FUNCTION)
#define PIN_INPUT_PULLDOWN        (IOMUX_PINCM_INENA_ENABLE | IOMUX_PINCM_PIPD_ENABLE | GPIO_FUNCTION)

#define DEBOUNCE_MS               (20UL)
#define HOLD_START_MS             (600UL)
#define HOLD_REPEAT_MS            (200UL)
#define PWM_STEPS                 (10U)
#define COMMAND_BUFFER_SIZE       (128U)
#define MAX_TOKENS                (8U)
#define MAX_INTEGRAL_STEPS        (20000UL)
#define MAX_BENCH_REPETITIONS     (100000UL)
#define MAX_PEEK_WORDS            (16UL)
#define DMA_MAX_WORDS             (1024UL)
#define DMA_CHANNEL               (0U)
#define DMA_SW_TRIGGER            (0U)
#define HW_TIMEOUT                (200000UL)

/* Registros del nucleo Cortex-M33 (System Control Space). */
#define REG32(addr)               (*(volatile uint32_t *)(addr))
#define SCB_CPUID                 REG32(0xE000ED00UL)
#define SCB_VTOR                  REG32(0xE000ED08UL)
#define SCB_CFSR                  REG32(0xE000ED28UL)
#define SCB_HFSR                  REG32(0xE000ED2CUL)
#define SCB_MMFAR                 REG32(0xE000ED34UL)
#define SCB_BFAR                  REG32(0xE000ED38UL)
#define SCB_CPACR                 REG32(0xE000ED88UL)
#define DEMCR                     REG32(0xE000EDFCUL)
#define DWT_CTRL                  REG32(0xE0001000UL)
#define DWT_CYCCNT                REG32(0xE0001004UL)

/*
 * CPACR: CP0 (bits 1:0) = TMU via CDE, CP10 (21:20) y CP11 (23:22) = FPU.
 * Arm exige que CP10 y CP11 tengan el mismo valor, por eso 0x00F00003.
 */
#define CPACR_FPU_AND_TMU         (0x00F00003UL)

/* ------------------------------------------------------------------------ */
/* Tipos y estado                                                           */
/* ------------------------------------------------------------------------ */

typedef struct
{
    bool raw;
    bool stable;
    uint32_t changed_at;
} ButtonState;

typedef struct
{
    float d;
    float q;
} ParkResult;

typedef union
{
    float f32;
    uint32_t u32;
} FloatBits;

typedef enum
{
    FN_SIN = 0,
    FN_COS,
    FN_ATAN,
    FN_SQRT,
    FN_EXP,
    FN_LN,
    FN_DIV,
    FN_INVALID
} MathFn;

static const uint8_t g_brightness_steps[] = {1U, 3U, 5U, 7U, 10U};
static char g_command[COMMAND_BUFFER_SIZE];
static uint32_t g_command_length;
static volatile float g_sink_f;
static volatile uint32_t g_sink_u;
static uint32_t g_crc_table[256];

static uint32_t g_dma_src[DMA_MAX_WORDS] __attribute__((aligned(16)));
static uint32_t g_dma_dst[DMA_MAX_WORDS] __attribute__((aligned(16)));

/* Vector oficial NIST SP 800-38A F.1.5 (AES-256 ECB), el mismo del SDK. */
static const uint8_t g_aes_key[32] __attribute__((aligned(16))) = {
    0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
    0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4};
static const uint8_t g_aes_plain[64] __attribute__((aligned(16))) = {
    0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a,
    0xae, 0x2d, 0x8a, 0x57, 0x1e, 0x03, 0xac, 0x9c, 0x9e, 0xb7, 0x6f, 0xac, 0x45, 0xaf, 0x8e, 0x51,
    0x30, 0xc8, 0x1c, 0x46, 0xa3, 0x5c, 0xe4, 0x11, 0xe5, 0xfb, 0xc1, 0x19, 0x1a, 0x0a, 0x52, 0xef,
    0xf6, 0x9f, 0x24, 0x45, 0xdf, 0x4f, 0x9b, 0x17, 0xad, 0x2b, 0x41, 0x7b, 0xe6, 0x6c, 0x37, 0x10};
static const uint8_t g_aes_expected[64] = {
    0xf3, 0xee, 0xd1, 0xbd, 0xb5, 0xd2, 0xa0, 0x3c, 0x06, 0x4b, 0x5a, 0x7e, 0x3d, 0xb1, 0x81, 0xf8,
    0x59, 0x1c, 0xcb, 0x10, 0xd4, 0x10, 0xed, 0x26, 0xdc, 0x5b, 0xa7, 0x4a, 0x31, 0x36, 0x28, 0x70,
    0xb6, 0xed, 0x21, 0xb9, 0x9c, 0xa6, 0xf4, 0xf9, 0xf1, 0x53, 0xe7, 0xb1, 0xbe, 0xaf, 0xed, 0x1d,
    0x23, 0x30, 0x4b, 0x7a, 0x39, 0xf9, 0xf3, 0xff, 0x06, 0x7d, 0x8d, 0x8f, 0x9e, 0x24, 0xec, 0xc7};
static uint8_t g_aes_out[64] __attribute__((aligned(16)));
static uint8_t g_aes_back[64] __attribute__((aligned(16)));

/* ------------------------------------------------------------------------ */
/* Arranque                                                                 */
/* ------------------------------------------------------------------------ */

void SystemInit(void)
{
    SCB_CPACR = CPACR_FPU_AND_TMU;
    __asm volatile ("dsb");
    __asm volatile ("isb");

    /* La tabla de vectores de esta imagen vive en SRAM. */
    SCB_VTOR = 0x20000000UL;
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

static void enable_fpu_and_tmu(void)
{
    /*
     * Leccion aprendida en la prueba del 01-10-2026: si el AXF tiene como
     * punto de entrada __main (valor por defecto de Keil), DSLite salta
     * directo a __main y NUNCA ejecuta Reset_Handler ni SystemInit. Por eso
     * el proyecto usa --entry=Reset_Handler y, por seguridad, main repite
     * aqui la configuracion de CPACR y VTOR.
     */
    SCB_CPACR |= CPACR_FPU_AND_TMU;
    SCB_VTOR = 0x20000000UL;
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

static void short_delay(void)
{
    for (volatile uint32_t i = 0; i < 64UL; ++i)
    {
        __asm volatile ("nop");
    }
}

static void gpio_reset_and_enable(GPIO_Regs *gpio)
{
    gpio->GPRCM.RSTCTL = GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETSTKYCLR_CLR | GPIO_RSTCTL_RESETASSERT_ASSERT;
    gpio->GPRCM.PWREN = GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE;
}

static void gpio_and_buttons_init(void)
{
    gpio_reset_and_enable(GPIO0);
    gpio_reset_and_enable(GPIO1);
    short_delay();

    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PA5] = PIN_OUTPUT_CONNECTED;
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PB0] = PIN_OUTPUT_CONNECTED;
    GPIO0->DOUTSET31_0 = LED_RED_MASK;
    GPIO1->DOUTSET31_0 = LED_GREEN_MASK;
    GPIO0->DOESET31_0  = LED_RED_MASK;
    GPIO1->DOESET31_0  = LED_GREEN_MASK;
    GPIO0->DOUTCLR31_0 = LED_RED_MASK;

    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PA6]  = PIN_INPUT_PULLDOWN;
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PA3]  = PIN_INPUT_PULLDOWN;
    IOMUX->SECCFG.PINCM[IOMUX_PINCM_PB13] = PIN_INPUT_PULLUP;
}

static void uart_init(void)
{
    DL_UART_Config config = {
        .mode = DL_UART_MODE_NORMAL,
        .direction = DL_UART_DIRECTION_TX_RX,
        .flowControl = DL_UART_FLOW_CONTROL_NONE,
        .parity = DL_UART_PARITY_NONE,
        .wordLength = DL_UART_WORD_LENGTH_8_BITS,
        .stopBits = DL_UART_STOP_BITS_ONE,
    };
    DL_UART_ClockConfig clock_config = {
        .clockSel = DL_UART_CLOCK_BUSCLK,
        .divideRatio = DL_UART_CLOCK_DIVIDE_RATIO_1,
    };

    DL_GPIO_initPeripheralOutputFunction(IOMUX_PINCM_PA0, IOMUX_PA0_UC1_TX_SDA_PICO);
    DL_GPIO_initPeripheralInputFunction(IOMUX_PINCM_PA1, IOMUX_PA1_UC1_RX_SCL_SCLK);

    DL_UART_reset(UC1_INST_PTR);
    DL_UART_enablePower(UC1_INST_PTR);
    while (!DL_UART_isPowerEnabled(UC1_INST_PTR))
    {
    }

    DL_UNICOMM_setIPMode(UC1_INST_PTR, DL_UNICOMM_UART);
    DL_UART_disable(UC1_INST_PTR);
    DL_UART_init(UC1_INST_PTR, &config);
    DL_UART_setClockConfig(UC1_INST_PTR, &clock_config);
    DL_UART_configBaudRate(UC1_INST_PTR, CPU_CLOCK_HZ, UART_BAUD);
    DL_UART_enableFIFOs(UC1_INST_PTR);
    DL_UART_setTXFIFOThreshold(UC1_INST_PTR, DL_UART_TX_FIFO_LEVEL_EMPTY);
    DL_UART_setRXFIFOThreshold(UC1_INST_PTR, DL_UART_RX_FIFO_LEVEL_NOT_EMPTY);
    DL_UART_enable(UC1_INST_PTR);
}

static void cycle_counter_init(void)
{
    DEMCR |= (1UL << 24);  /* TRCENA: habilita DWT */
    DWT_CYCCNT = 0UL;
    DWT_CTRL |= 1UL;       /* CYCCNTENA */
}

static void accelerators_init(void)
{
    DL_CRCP_reset(CRC);
    DL_CRCP_enablePower(CRC);
    DL_AES_reset(AES);
    DL_AES_enablePower(AES);
    short_delay();

    /* Tabla para el CRC-32/MPEG-2 por software (comparacion justa). */
    for (uint32_t i = 0; i < 256UL; ++i)
    {
        uint32_t c = i << 24;
        for (uint32_t b = 0; b < 8UL; ++b)
        {
            c = (c & 0x80000000UL) ? ((c << 1) ^ 0x04C11DB7UL) : (c << 1);
        }
        g_crc_table[i] = c;
    }
}

/* ------------------------------------------------------------------------ */
/* Salida por UART                                                          */
/* ------------------------------------------------------------------------ */

static void uart_putc(char ch)
{
    DL_UART_transmitDataBlocking(UC1_INST_PTR, (uint8_t)ch);
}

static void uart_puts(const char *text)
{
    while (*text != '\0')
    {
        uart_putc(*text++);
    }
}

static void uart_put_u32(uint32_t value)
{
    char digits[10];
    uint32_t count = 0U;
    if (value == 0UL)
    {
        uart_putc('0');
        return;
    }
    while ((value != 0UL) && (count < sizeof(digits)))
    {
        digits[count++] = (char)('0' + (value % 10UL));
        value /= 10UL;
    }
    while (count != 0U)
    {
        uart_putc(digits[--count]);
    }
}

static void uart_put_hex(uint32_t value, uint32_t digits)
{
    static const char hex[] = "0123456789ABCDEF";
    for (int32_t shift = (int32_t)(digits * 4UL) - 4; shift >= 0; shift -= 4)
    {
        uart_putc(hex[(value >> (uint32_t)shift) & 0xFUL]);
    }
}

static void uart_put_hex32(uint32_t value)
{
    uart_puts("0x");
    uart_put_hex(value, 8UL);
}

static void uart_put_float(float value)
{
    if (value != value)
    {
        uart_puts("NaN");
        return;
    }
    if (value < 0.0f)
    {
        uart_putc('-');
        value = -value;
    }
    if (value > 4294960000.0f)
    {
        uart_puts("OVERFLOW");
        return;
    }
    uint32_t whole = (uint32_t)value;
    uint32_t fraction = (uint32_t)((value - (float)whole) * 1000000.0f + 0.5f);
    if (fraction >= 1000000UL)
    {
        ++whole;
        fraction -= 1000000UL;
    }
    uart_put_u32(whole);
    uart_putc('.');
    for (uint32_t divisor = 100000UL; divisor != 0UL; divisor /= 10UL)
    {
        uart_putc((char)('0' + ((fraction / divisor) % 10UL)));
    }
}

/* Notacion cientifica corta para errores pequenos: 1.23E-07 */
static void uart_put_sci(float value)
{
    if (value < 0.0f)
    {
        uart_putc('-');
        value = -value;
    }
    if (value == 0.0f)
    {
        uart_puts("0");
        return;
    }
    int32_t exponent = 0;
    while (value >= 10.0f)
    {
        value /= 10.0f;
        ++exponent;
    }
    while (value < 1.0f)
    {
        value *= 10.0f;
        --exponent;
    }
    uint32_t scaled = (uint32_t)(value * 100.0f + 0.5f);
    if (scaled >= 1000UL)
    {
        scaled /= 10UL;
        ++exponent;
    }
    uart_put_u32(scaled / 100UL);
    uart_putc('.');
    uart_putc((char)('0' + ((scaled / 10UL) % 10UL)));
    uart_putc((char)('0' + (scaled % 10UL)));
    uart_putc('E');
    uart_putc((exponent < 0) ? '-' : '+');
    const uint32_t mag = (uint32_t)((exponent < 0) ? -exponent : exponent);
    uart_putc((char)('0' + (mag / 10UL)));
    uart_putc((char)('0' + (mag % 10UL)));
}

static void prompt(void)
{
    uart_puts("\r\n> ");
}

/* ------------------------------------------------------------------------ */
/* Diagnostico de fallos: "preguntarle al chip por que se cayo"             */
/* ------------------------------------------------------------------------ */

__attribute__((used)) void hardfault_report(const uint32_t *frame)
{
    uart_puts("\r\n!!! HARDFAULT\r\n");
    uart_puts("CFSR="); uart_put_hex32(SCB_CFSR);
    uart_puts(" HFSR="); uart_put_hex32(SCB_HFSR);
    uart_puts(" CPACR="); uart_put_hex32(SCB_CPACR);
    uart_puts("\r\nPC="); uart_put_hex32(frame[6]);
    uart_puts(" LR="); uart_put_hex32(frame[5]);
    uart_puts(" MMFAR="); uart_put_hex32(SCB_MMFAR);
    uart_puts(" BFAR="); uart_put_hex32(SCB_BFAR);
    uart_puts("\r\nCPU detenida. Presione nRST para volver al programa de flash.\r\n");
    for (;;)
    {
        GPIO0->DOUTTGL31_0 = LED_RED_MASK;
        for (volatile uint32_t i = 0; i < 400000UL; ++i)
        {
        }
    }
}

__attribute__((naked)) void HardFault_Handler(void)
{
    __asm volatile(
        "tst lr, #4      \n"
        "ite eq          \n"
        "mrseq r0, msp   \n"
        "mrsne r0, psp   \n"
        "b hardfault_report \n");
}

/* ------------------------------------------------------------------------ */
/* Parser                                                                   */
/* ------------------------------------------------------------------------ */

static char to_upper(char c)
{
    return ((c >= 'a') && (c <= 'z')) ? (char)(c - ('a' - 'A')) : c;
}

static bool text_equal(const char *a, const char *b)
{
    while ((*a != '\0') && (*b != '\0'))
    {
        if (to_upper(*a++) != to_upper(*b++)) return false;
    }
    return (*a == '\0') && (*b == '\0');
}

static uint32_t split_tokens(char *line, char **tokens, uint32_t capacity)
{
    uint32_t count = 0U;
    char *cursor = line;
    while ((*cursor != '\0') && (count < capacity))
    {
        while ((*cursor == ' ') || (*cursor == '\t')) ++cursor;
        if (*cursor == '\0') break;
        tokens[count++] = cursor;
        while ((*cursor != '\0') && (*cursor != ' ') && (*cursor != '\t')) ++cursor;
        if (*cursor != '\0') *cursor++ = '\0';
    }
    return count;
}

static bool parse_u32(const char *text, uint32_t *value)
{
    uint32_t result = 0UL;
    uint32_t base = 10UL;
    if ((text[0] == '0') && ((text[1] == 'x') || (text[1] == 'X')))
    {
        base = 16UL;
        text += 2;
    }
    if (*text == '\0') return false;
    while (*text != '\0')
    {
        const char c = to_upper(*text++);
        uint32_t digit;
        if ((c >= '0') && (c <= '9')) digit = (uint32_t)(c - '0');
        else if ((base == 16UL) && (c >= 'A') && (c <= 'F')) digit = (uint32_t)(c - 'A' + 10);
        else return false;
        result = (result * base) + digit;
    }
    *value = result;
    return true;
}

static bool parse_float(const char *text, float *value)
{
    bool negative = false;
    bool any = false;
    float result = 0.0f;
    float scale = 0.1f;
    if (*text == '-')
    {
        negative = true;
        ++text;
    }
    else if (*text == '+')
    {
        ++text;
    }
    while ((*text >= '0') && (*text <= '9'))
    {
        any = true;
        result = (result * 10.0f) + (float)(*text++ - '0');
    }
    if (*text == '.')
    {
        ++text;
        while ((*text >= '0') && (*text <= '9'))
        {
            any = true;
            result += (float)(*text++ - '0') * scale;
            scale *= 0.1f;
        }
    }
    if (!any || (*text != '\0')) return false;
    *value = negative ? -result : result;
    return true;
}

#pragma clang attribute pop

/* ------------------------------------------------------------------------ */
/* TMU: funciones matematicas por instrucciones CDE (coprocesador CP0)       */
/* Copiadas de fastrts_tmu.h del SDK para que se vea cada instruccion.       */
/* ------------------------------------------------------------------------ */

#define TMU_INV_2PI   (0.15915494309190f)
#define TMU_TWO_PI    (6.28318530717959f)
#define TMU_LN2       (0.6931471805f)

static inline float tmu_sin(float x)
{
    FloatBits in, out;
    in.f32 = x * TMU_INV_2PI;               /* la TMU trabaja en "vueltas" */
    out.u32 = __arm_vcx2_u32(0, in.u32, 0); /* CX op 0 = SINPU */
    return out.f32;
}

static inline float tmu_cos(float x)
{
    FloatBits in, out;
    in.f32 = x * TMU_INV_2PI;
    out.u32 = __arm_vcx2_u32(0, in.u32, 1); /* op 1 = COSPU */
    return out.f32;
}

static inline float tmu_atan(float x)
{
    FloatBits in, out;
    in.f32 = x;
    out.u32 = __arm_vcx2_u32(0, in.u32, 2); /* op 2 = ATANPU */
    return out.f32 * TMU_TWO_PI;
}

static inline float tmu_sqrt(float x)
{
    FloatBits in, out;
    in.f32 = x;
    out.u32 = __arm_vcx2_u32(0, in.u32, 3); /* op 3 = SQRT */
    return out.f32;
}

static inline float tmu_exp(float x)
{
    FloatBits in, out;
    in.f32 = x * -1.44269504f;
    out.u32 = __arm_vcx2_u32(0, in.u32, 4); /* op 4 = IEXP2 */
    if (x > 0.0f)
    {
        out.f32 = 1.0f / out.f32;
    }
    return out.f32;
}

static inline float tmu_ln(float x)
{
    FloatBits in, out;
    in.f32 = x;
    out.u32 = __arm_vcx2_u32(0, in.u32, 5); /* op 5 = LOG2 */
    return out.f32 * TMU_LN2;
}

static inline float tmu_div(float y, float x)
{
    FloatBits a, b, out;
    a.f32 = y;
    b.f32 = x;
    out.u32 = __arm_vcx3_u32(0, a.u32, b.u32, 0); /* vcx3 op 0 = DIV */
    return out.f32;
}

static MathFn parse_fn(const char *name)
{
    if (text_equal(name, "SIN")) return FN_SIN;
    if (text_equal(name, "COS")) return FN_COS;
    if (text_equal(name, "ATAN")) return FN_ATAN;
    if (text_equal(name, "SQRT")) return FN_SQRT;
    if (text_equal(name, "EXP")) return FN_EXP;
    if (text_equal(name, "LN")) return FN_LN;
    if (text_equal(name, "DIV")) return FN_DIV;
    return FN_INVALID;
}

__attribute__((noinline)) static float cpu_eval(MathFn fn, float x, float y)
{
    switch (fn)
    {
        case FN_SIN:  return sinf(x);
        case FN_COS:  return cosf(x);
        case FN_ATAN: return atanf(x);
        case FN_SQRT: return sqrtf(x);
        case FN_EXP:  return expf(x);
        case FN_LN:   return logf(x);
        case FN_DIV:  return x / y;
        default:      return 0.0f;
    }
}

__attribute__((noinline)) static float tmu_eval(MathFn fn, float x, float y)
{
    switch (fn)
    {
        case FN_SIN:  return tmu_sin(x);
        case FN_COS:  return tmu_cos(x);
        case FN_ATAN: return tmu_atan(x);
        case FN_SQRT: return tmu_sqrt(x);
        case FN_EXP:  return tmu_exp(x);
        case FN_LN:   return tmu_ln(x);
        case FN_DIV:  return tmu_div(x, y);
        default:      return 0.0f;
    }
}

/*
 * Benchmark honesto: cada iteracion usa una entrada distinta y TODOS los
 * resultados se acumulan, asi el compilador no puede eliminar iteraciones.
 */
#define BENCH_LOOP(EXPR)                                  \
    do {                                                  \
        float acc = 0.0f;                                 \
        float x = x0;                                     \
        const uint32_t t0 = DWT_CYCCNT;                   \
        _Pragma("clang loop unroll(disable)")             \
        for (uint32_t i = 0; i < n; ++i)                  \
        {                                                 \
            acc += (EXPR);                                \
            x += step;                                    \
        }                                                 \
        g_sink_f = acc;  /* usar el resultado ANTES de leer DWT */ \
        cycles = DWT_CYCCNT - t0;                         \
    } while (0)

__attribute__((noinline)) static uint32_t bench_cpu(MathFn fn, float x0, float step, float y, uint32_t n)
{
    uint32_t cycles = 0UL;
    switch (fn)
    {
        case FN_SIN:  BENCH_LOOP(sinf(x)); break;
        case FN_COS:  BENCH_LOOP(cosf(x)); break;
        case FN_ATAN: BENCH_LOOP(atanf(x)); break;
        case FN_SQRT: BENCH_LOOP(sqrtf(x)); break;
        case FN_EXP:  BENCH_LOOP(expf(x)); break;
        case FN_LN:   BENCH_LOOP(logf(x)); break;
        case FN_DIV:  BENCH_LOOP(x / y); break;
        default: break;
    }
    return cycles;
}

__attribute__((noinline)) static uint32_t bench_tmu(MathFn fn, float x0, float step, float y, uint32_t n)
{
    uint32_t cycles = 0UL;
    switch (fn)
    {
        case FN_SIN:  BENCH_LOOP(tmu_sin(x)); break;
        case FN_COS:  BENCH_LOOP(tmu_cos(x)); break;
        case FN_ATAN: BENCH_LOOP(tmu_atan(x)); break;
        case FN_SQRT: BENCH_LOOP(tmu_sqrt(x)); break;
        case FN_EXP:  BENCH_LOOP(tmu_exp(x)); break;
        case FN_LN:   BENCH_LOOP(tmu_ln(x)); break;
        case FN_DIV:  BENCH_LOOP(tmu_div(x, y)); break;
        default: break;
    }
    return cycles;
}

__attribute__((noinline)) static ParkResult park_cpu(float alpha, float beta, float angle)
{
    const float s = sinf(angle);
    const float c = cosf(angle);
    ParkResult r = {(alpha * c) + (beta * s), (beta * c) - (alpha * s)};
    return r;
}

__attribute__((noinline)) static ParkResult park_tmu(float alpha, float beta, float angle)
{
    const float s = tmu_sin(angle);
    const float c = tmu_cos(angle);
    ParkResult r = {(alpha * c) + (beta * s), (beta * c) - (alpha * s)};
    return r;
}

__attribute__((noinline)) static uint32_t bench_park(bool use_tmu, uint32_t n)
{
    float acc = 0.0f;
    float angle = 0.0f;
    const uint32_t t0 = DWT_CYCCNT;
    _Pragma("clang loop unroll(disable)")
    for (uint32_t i = 0; i < n; ++i)
    {
        const ParkResult r = use_tmu ? park_tmu(1.0f, 0.5f, angle) : park_cpu(1.0f, 0.5f, angle);
        acc += r.d + r.q;
        angle += 0.001f;
    }
    g_sink_f = acc;
    return DWT_CYCCNT - t0;
}

/* Regla del trapecio: extremos con peso 1/2, puntos interiores con peso 1. */
__attribute__((noinline)) static float integrate_sine(float start, float end, uint32_t steps, bool use_tmu)
{
    const float width = (end - start) / (float)steps;
    float sum = 0.0f;
    for (uint32_t i = 0UL; i <= steps; ++i)
    {
        const float x = start + ((float)i * width);
        const float y = use_tmu ? tmu_sin(x) : sinf(x);
        sum += ((i == 0UL) || (i == steps)) ? (0.5f * y) : y;
    }
    return sum * width;
}

/* ------------------------------------------------------------------------ */
/* CRC-32/MPEG-2: hardware (CRCP) contra software (tabla en CPU)             */
/* ------------------------------------------------------------------------ */

__attribute__((noinline)) static uint32_t crc32_sw(const uint8_t *data, uint32_t len)
{
    uint32_t crc = 0xFFFFFFFFUL;
    for (uint32_t i = 0; i < len; ++i)
    {
        crc = (crc << 8) ^ g_crc_table[((crc >> 24) ^ data[i]) & 0xFFUL];
    }
    return crc;
}

static void crc32_hw_start(void)
{
    DL_CRCP_init(CRC, DL_CRCP_POLYNOMIAL_SIZE_32, DL_CRCP_BIT_NOT_REVERSED, DL_CRCP_INPUT_ENDIANESS_LITTLE_ENDIAN,
                 DL_CRCP_OUTPUT_BYTESWAP_DISABLED);
    DL_CRCP_setPolynomial(CRC, DL_CRCP_CRCPOLY_POLYNOMIAL_32_MPEG2);
    DL_CRCP_setSeed32(CRC, DL_CRCP_CRCSEED_SEED_32_MPEG2);
}

__attribute__((noinline)) static uint32_t crc32_hw_bytes(const uint8_t *data, uint32_t len)
{
    crc32_hw_start();
    for (uint32_t i = 0; i < len; ++i)
    {
        DL_CRCP_feedData8(CRC, data[i]);
    }
    return DL_CRCP_getResult32(CRC);
}

__attribute__((noinline)) static uint32_t crc32_hw_words(const uint32_t *data, uint32_t words)
{
    crc32_hw_start();
    for (uint32_t i = 0; i < words; ++i)
    {
        DL_CRCP_feedData32(CRC, data[i]);
    }
    return DL_CRCP_getResult32(CRC);
}

/* ------------------------------------------------------------------------ */
/* AES por hardware                                                         */
/* ------------------------------------------------------------------------ */

__attribute__((noinline)) static bool aes_ecb(const uint8_t *key, DL_AES_DIR dir, const uint8_t *in, uint8_t *out, uint32_t blocks)
{
    DL_AES_setMode(AES, DL_AES_MODE_ECB);
    DL_AES_setDirection(AES, dir);
    if (DL_AES_setKey(AES, key, DL_AES_KEY_SIZE_256_BIT) != DL_AES_STATUS_SUCCESS) return false;

    for (uint32_t b = 0; b < blocks; ++b)
    {
        uint32_t timeout = HW_TIMEOUT;
        while (!DL_AES_isInputReady(AES))
        {
            if (--timeout == 0UL) return false;
        }
        if (DL_AES_loadInputData(AES, (uint8_t *)&in[b * 16UL]) != DL_AES_STATUS_SUCCESS) return false;
        timeout = HW_TIMEOUT;
        while (!DL_AES_isOutputReady(AES))
        {
            if (--timeout == 0UL) return false;
        }
        if (DL_AES_readOutputData(AES, &out[b * 16UL]) != DL_AES_STATUS_SUCCESS) return false;
    }
    return true;
}

#pragma clang attribute push (__attribute__((minsize)), apply_to = function)

static void put_hex_bytes(const uint8_t *data, uint32_t len)
{
    for (uint32_t i = 0; i < len; ++i)
    {
        uart_put_hex(data[i], 2UL);
    }
}

/* ------------------------------------------------------------------------ */
/* DMA: delegar una copia y medir cuanto trabajo hace la CPU mientras tanto  */
/* ------------------------------------------------------------------------ */

__attribute__((noinline)) static bool dma_copy(uint32_t *src, uint32_t *dst, uint32_t words, uint32_t *cycles, uint32_t *cpu_work)
{
    const DL_DMA_Config cfg = {
        .trigger = DMA_SW_TRIGGER,
        .triggerType = DL_DMA_TRIGGER_TYPE_EXTERNAL,
        .transferMode = DL_DMA_SINGLE_BLOCK_TRANSFER_MODE,
        .extendedMode = DL_DMA_NORMAL_MODE,
        .srcWidth = DL_DMA_WIDTH_WORD,
        .destWidth = DL_DMA_WIDTH_WORD,
        .srcIncrement = DL_DMA_ADDR_INCREMENT,
        .destIncrement = DL_DMA_ADDR_INCREMENT,
    };
    uint32_t work = 0UL;
    uint32_t timeout = HW_TIMEOUT;

    DL_DMA_disableChannel(DMA0, DMA_CHANNEL);
    DL_DMA_initChannel(DMA0, DMA_CHANNEL, &cfg);
    DL_DMA_setSrcAddr(DMA0, DMA_CHANNEL, (uint32_t)src);
    DL_DMA_setDestAddr(DMA0, DMA_CHANNEL, (uint32_t)dst);
    DL_DMA_setTransferSize(DMA0, DMA_CHANNEL, (uint16_t)words);
    DL_DMA_clearInterruptStatus(DMA0, DL_DMA_INTERRUPT_CHANNEL0);
    DL_DMA_enableChannel(DMA0, DMA_CHANNEL);

    const uint32_t t0 = DWT_CYCCNT;
    DL_DMA_startTransfer(DMA0, DMA_CHANNEL);
    while (DL_DMA_getRawInterruptStatus(DMA0, DL_DMA_INTERRUPT_CHANNEL0) == 0UL)
    {
        ++work; /* "trabajo" de la CPU mientras el DMA copia */
        if (--timeout == 0UL) break;
    }
    *cycles = DWT_CYCCNT - t0;
    *cpu_work = work;
    DL_DMA_clearInterruptStatus(DMA0, DL_DMA_INTERRUPT_CHANNEL0);
    DL_DMA_disableChannel(DMA0, DMA_CHANNEL);
    return timeout != 0UL;
}

/* ------------------------------------------------------------------------ */
/* Lectura segura de memoria                                                */
/* ------------------------------------------------------------------------ */

static bool peek_allowed(uint32_t addr, uint32_t words)
{
    const uint32_t end = addr + (words * 4UL) - 1UL;
    if ((addr & 3UL) != 0UL || end < addr) return false;
    if (end <= 0x0007FFFFUL) return true;                                  /* flash */
    if ((addr >= 0x20000000UL) && (end <= 0x2001FFFFUL)) return true;      /* SRAM */
    if ((addr >= 0x60111000UL) && (end <= 0x601113FFUL)) return true;      /* fabrica/OTP */
    if ((addr >= 0xE000E000UL) && (end <= 0xE000EFFFUL)) return true;      /* SCB/NVIC */
    if ((addr >= 0xE0001000UL) && (end <= 0xE0001FFFUL)) return true;      /* DWT */
    return false;
}

/* ------------------------------------------------------------------------ */
/* Comandos                                                                 */
/* ------------------------------------------------------------------------ */

static void print_help(void)
{
    uart_puts("\r\nPreguntar al chip:\r\n");
    uart_puts("  PING | INFO | ID\r\n");
    uart_puts("  PEEK direccion [palabras]   ej: PEEK 0xE000ED00 4\r\n");
    uart_puts("Matematicas CPU vs TMU:\r\n");
    uart_puts("  MATH SIN|COS|ATAN|SQRT|EXP|LN x  |  MATH DIV x y\r\n");
    uart_puts("  BENCH MATH fn x0 paso n          |  BENCH PARK n\r\n");
    uart_puts("  INTEGRAL CPU|TMU inicio fin pasos SIN  (trapecio)\r\n");
    uart_puts("  PARK CPU|TMU alpha beta angulo_rad\r\n");
    uart_puts("Aceleradores:\r\n");
    uart_puts("  CRC TEST | CRC FLASH inicio bytes\r\n");
    uart_puts("  AES TEST | AES TEXT palabra\r\n");
    uart_puts("  DMA COPY palabras(<=1024)\r\n");
    uart_puts("Diagnostico:\r\n");
    uart_puts("  FAULT TMU   (provoca un fallo controlado; luego pulse nRST)");
    prompt();
}

static void cmd_info(void)
{
    const uint32_t cpuid = SCB_CPUID;
    uart_puts("FW="); uart_puts(LAB_VERSION);
    uart_puts(" CPU=CORTEX-M33 CPUID="); uart_put_hex32(cpuid);
    uart_puts(" (PARTNO="); uart_put_hex((cpuid >> 4) & 0xFFFUL, 3UL);
    uart_puts(" r"); uart_put_u32((cpuid >> 20) & 0xFUL);
    uart_puts("p"); uart_put_u32(cpuid & 0xFUL);
    uart_puts(")\r\nCLOCK_HZ="); uart_put_u32(CPU_CLOCK_HZ);
    uart_puts(" VTOR="); uart_put_hex32(SCB_VTOR);
    uart_puts(" CPACR="); uart_put_hex32(SCB_CPACR);
    uart_puts("\r\nLOAD=SRAM FLASH_WRITES=0");
    prompt();
}

static void cmd_id(void)
{
    uart_puts("MANUFACTURER="); uart_put_hex(DL_FactoryRegion_getManufacturerCode(), 3UL);
    uart_puts(" PARTNUM="); uart_put_hex(DL_FactoryRegion_getPartNumber(), 4UL);
    uart_puts(" VERSION="); uart_put_u32(DL_FactoryRegion_getVersion());
    uart_puts("\r\nUSERID_PART="); uart_put_hex(DL_FactoryRegion_getUserIDPart(), 4UL);
    uart_puts(" VARIANT="); uart_put_hex(DL_FactoryRegion_getUserIDVariant(), 2UL);
    uart_puts(" REV="); uart_put_u32(DL_FactoryRegion_getUserIDMajorRev());
    uart_puts("."); uart_put_u32(DL_FactoryRegion_getUserIDMinorRev());
    uart_puts("\r\nTRACEID="); uart_put_hex32(DL_FactoryRegion_getTraceID());
    uart_puts(" MAIN_FLASH_KB="); uart_put_u32(DL_FactoryRegion_getMAINFlashSize());
    uart_puts(" SRAM_KB="); uart_put_u32(DL_FactoryRegion_getSRAMSize());
    uart_puts(" DATA_FLASH_KB="); uart_put_u32(DL_FactoryRegion_getDATAFlashSize());
    uart_puts(" BANKS="); uart_put_u32(DL_FactoryRegion_getNumBanks());
    prompt();
}

static void cmd_peek(char **tok, uint32_t count)
{
    uint32_t addr;
    uint32_t words = 1UL;
    if ((count < 2U) || !parse_u32(tok[1], &addr) || ((count >= 3U) && !parse_u32(tok[2], &words)) ||
        (words == 0UL) || (words > MAX_PEEK_WORDS))
    {
        uart_puts("ERR uso: PEEK 0xDIRECCION [1..16]");
        prompt();
        return;
    }
    if (!peek_allowed(addr, words))
    {
        uart_puts("ERR rango no permitido (solo flash, SRAM, fabrica, SCB y DWT; alineado a 4)");
        prompt();
        return;
    }
    for (uint32_t i = 0; i < words; ++i)
    {
        if ((i % 4UL) == 0UL)
        {
            if (i != 0UL) uart_puts("\r\n");
            uart_put_hex32(addr + (i * 4UL));
            uart_puts(":");
        }
        uart_putc(' ');
        uart_put_hex32(REG32(addr + (i * 4UL)));
    }
    prompt();
}

static void cmd_math(char **tok, uint32_t count)
{
    const MathFn fn = (count >= 3U) ? parse_fn(tok[1]) : FN_INVALID;
    float x;
    float y = 1.0f;
    if ((fn == FN_INVALID) || !parse_float(tok[2], &x) ||
        ((fn == FN_DIV) && ((count < 4U) || !parse_float(tok[3], &y))))
    {
        uart_puts("ERR uso: MATH SIN|COS|ATAN|SQRT|EXP|LN x  o  MATH DIV x y");
        prompt();
        return;
    }
    volatile float vx = x;
    volatile float vy = y;

    uint32_t t0 = DWT_CYCCNT;
    const float r_cpu = cpu_eval(fn, vx, vy);
    g_sink_f = r_cpu;
    const uint32_t c_cpu = DWT_CYCCNT - t0;
    t0 = DWT_CYCCNT;
    const float r_tmu = tmu_eval(fn, vx, vy);
    g_sink_f = r_tmu;
    const uint32_t c_tmu = DWT_CYCCNT - t0;
    const float err = r_tmu - r_cpu;

    uart_puts("CPU="); uart_put_float(r_cpu);
    uart_puts(" TMU="); uart_put_float(r_tmu);
    uart_puts(" ERR="); uart_put_sci(err);
    uart_puts("\r\nCYCLES_CPU="); uart_put_u32(c_cpu);
    uart_puts(" CYCLES_TMU="); uart_put_u32(c_tmu);
    prompt();
}

static void report_bench(uint32_t c_cpu, uint32_t c_tmu, uint32_t n)
{
    uart_puts("CPU_TOTAL="); uart_put_u32(c_cpu);
    uart_puts(" CPU_POR_LLAMADA="); uart_put_u32(c_cpu / n);
    uart_puts("\r\nTMU_TOTAL="); uart_put_u32(c_tmu);
    uart_puts(" TMU_POR_LLAMADA="); uart_put_u32(c_tmu / n);
    uart_puts("\r\nACELERACION=");
    uart_put_float((c_tmu != 0UL) ? ((float)c_cpu / (float)c_tmu) : 0.0f);
    uart_puts("x");
    prompt();
}

static void cmd_bench(char **tok, uint32_t count)
{
    if ((count == 6U) && text_equal(tok[1], "MATH"))
    {
        const MathFn fn = parse_fn(tok[2]);
        float x0, step;
        uint32_t n;
        if ((fn == FN_INVALID) || !parse_float(tok[3], &x0) || !parse_float(tok[4], &step) ||
            !parse_u32(tok[5], &n) || (n == 0UL) || (n > MAX_BENCH_REPETITIONS))
        {
            uart_puts("ERR uso: BENCH MATH fn x0 paso n   (DIV usa y=1.7)");
            prompt();
            return;
        }
        const uint32_t c_cpu = bench_cpu(fn, x0, step, 1.7f, n);
        const uint32_t c_tmu = bench_tmu(fn, x0, step, 1.7f, n);
        report_bench(c_cpu, c_tmu, n);
        return;
    }
    if ((count == 3U) && text_equal(tok[1], "PARK"))
    {
        uint32_t n;
        if (!parse_u32(tok[2], &n) || (n == 0UL) || (n > MAX_BENCH_REPETITIONS))
        {
            uart_puts("ERR uso: BENCH PARK n");
            prompt();
            return;
        }
        const uint32_t c_cpu = bench_park(false, n);
        const uint32_t c_tmu = bench_park(true, n);
        report_bench(c_cpu, c_tmu, n);
        return;
    }
    uart_puts("ERR uso: BENCH MATH fn x0 paso n  |  BENCH PARK n");
    prompt();
}

static void cmd_integral(char **tok, uint32_t count)
{
    float start, end;
    uint32_t steps;
    const bool use_tmu = (count == 6U) && text_equal(tok[1], "TMU");
    const bool mode_ok = (count == 6U) && (use_tmu || text_equal(tok[1], "CPU"));
    if (!mode_ok || !parse_float(tok[2], &start) || !parse_float(tok[3], &end) || !parse_u32(tok[4], &steps) ||
        (steps == 0UL) || (steps > MAX_INTEGRAL_STEPS) || !text_equal(tok[5], "SIN"))
    {
        uart_puts("ERR uso: INTEGRAL CPU|TMU inicio fin pasos SIN");
        prompt();
        return;
    }
    const uint32_t t0 = DWT_CYCCNT;
    const float result = integrate_sine(start, end, steps, use_tmu);
    g_sink_f = result;
    const uint32_t cycles = DWT_CYCCNT - t0;
    uart_puts("OK REGLA=TRAPECIO RESULT="); uart_put_float(result);
    uart_puts(" CYCLES="); uart_put_u32(cycles);
    prompt();
}

static void cmd_park(char **tok, uint32_t count)
{
    float alpha, beta, angle;
    const bool use_tmu = (count == 5U) && text_equal(tok[1], "TMU");
    const bool mode_ok = (count == 5U) && (use_tmu || text_equal(tok[1], "CPU"));
    if (!mode_ok || !parse_float(tok[2], &alpha) || !parse_float(tok[3], &beta) || !parse_float(tok[4], &angle))
    {
        uart_puts("ERR uso: PARK CPU|TMU alpha beta angulo_rad");
        prompt();
        return;
    }
    const uint32_t t0 = DWT_CYCCNT;
    const ParkResult r = use_tmu ? park_tmu(alpha, beta, angle) : park_cpu(alpha, beta, angle);
    g_sink_f = r.d + r.q;
    const uint32_t cycles = DWT_CYCCNT - t0;
    uart_puts("OK D="); uart_put_float(r.d);
    uart_puts(" Q="); uart_put_float(r.q);
    uart_puts(" CYCLES="); uart_put_u32(cycles);
    prompt();
}

static void cmd_crc(char **tok, uint32_t count)
{
    if ((count == 2U) && text_equal(tok[1], "TEST"))
    {
        static const uint8_t vector[12] __attribute__((aligned(4))) = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
        const uint32_t expected = 0x0376E6E7UL; /* CRC-32/MPEG-2("123456789") */
        const uint32_t sw = crc32_sw(vector, 9UL);
        const uint32_t hw8 = crc32_hw_bytes(vector, 9UL);
        uart_puts("VECTOR=\"123456789\" ESPERADO="); uart_put_hex32(expected);
        uart_puts("\r\nSW="); uart_put_hex32(sw);
        uart_puts(" HW="); uart_put_hex32(hw8);
        uart_puts(((sw == expected) && (hw8 == expected)) ? " PASS" : " FAIL");
        prompt();
        return;
    }
    if ((count == 4U) && text_equal(tok[1], "FLASH"))
    {
        uint32_t start, len;
        if (!parse_u32(tok[2], &start) || !parse_u32(tok[3], &len) || (len == 0UL) || ((start & 3UL) != 0UL) ||
            ((len & 3UL) != 0UL) || ((start + len) > 0x00080000UL) || ((start + len) < start))
        {
            uart_puts("ERR uso: CRC FLASH inicio bytes (alineados a 4, dentro de 0..0x7FFFF)");
            prompt();
            return;
        }
        const uint8_t *flash = (const uint8_t *)start;
        uint32_t t0 = DWT_CYCCNT;
        const uint32_t sw = crc32_sw(flash, len);
        g_sink_u = sw;
        const uint32_t c_sw = DWT_CYCCNT - t0;
        t0 = DWT_CYCCNT;
        const uint32_t hw = crc32_hw_words((const uint32_t *)start, len / 4UL);
        g_sink_u = hw;
        const uint32_t c_hw = DWT_CYCCNT - t0;
        const uint32_t hw8 = crc32_hw_bytes(flash, (len < 16UL) ? len : 16UL);
        const uint32_t sw16 = crc32_sw(flash, (len < 16UL) ? len : 16UL);
        uart_puts("RANGO="); uart_put_hex32(start); uart_puts("+"); uart_put_u32(len);
        uart_puts("\r\nCRC_SW="); uart_put_hex32(sw); uart_puts(" CICLOS_SW="); uart_put_u32(c_sw);
        uart_puts("\r\nCRC_HW="); uart_put_hex32(hw); uart_puts(" CICLOS_HW="); uart_put_u32(c_hw);
        uart_puts((sw == hw) ? " IGUALES" : " DIFERENTES");
        uart_puts((hw8 == sw16) ? " (modo byte OK)" : " (modo byte DIFERENTE)");
        prompt();
        return;
    }
    uart_puts("ERR uso: CRC TEST | CRC FLASH inicio bytes");
    prompt();
}

static void cmd_aes(char **tok, uint32_t count)
{
    if ((count == 2U) && text_equal(tok[1], "TEST"))
    {
        uint32_t t0 = DWT_CYCCNT;
        const bool ok_enc = aes_ecb(g_aes_key, DL_AES_DIR_ENCRYPT, g_aes_plain, g_aes_out, 4UL);
        const uint32_t c_enc = DWT_CYCCNT - t0;
        t0 = DWT_CYCCNT;
        const bool ok_dec = aes_ecb(g_aes_key, DL_AES_DIR_DECRYPT, g_aes_out, g_aes_back, 4UL);
        const uint32_t c_dec = DWT_CYCCNT - t0;
        const bool enc_match = ok_enc && (memcmp(g_aes_out, g_aes_expected, 64U) == 0);
        const bool dec_match = ok_dec && (memcmp(g_aes_back, g_aes_plain, 64U) == 0);
        uart_puts("NIST SP800-38A F.1.5 AES-256-ECB, 4 bloques (64 bytes)\r\n");
        uart_puts("CIFRADO_BLOQUE1="); put_hex_bytes(g_aes_out, 16UL);
        uart_puts("\r\nCIFRAR="); uart_puts(enc_match ? "PASS" : "FAIL");
        uart_puts(" CICLOS="); uart_put_u32(c_enc);
        uart_puts(" | DESCIFRAR="); uart_puts(dec_match ? "PASS" : "FAIL");
        uart_puts(" CICLOS="); uart_put_u32(c_dec);
        prompt();
        return;
    }
    if ((count == 3U) && text_equal(tok[1], "TEXT"))
    {
        uint8_t block[32] __attribute__((aligned(4))) = {0};
        uint8_t cipher[32] __attribute__((aligned(4)));
        uint8_t plain[33] __attribute__((aligned(4)));
        const uint32_t len = (uint32_t)strlen(tok[2]);
        const uint32_t used = (len > 32UL) ? 32UL : len;
        const uint32_t blocks = (used > 16UL) ? 2UL : 1UL;
        memcpy(block, tok[2], used);
        if (!aes_ecb(g_aes_key, DL_AES_DIR_ENCRYPT, block, cipher, blocks) ||
            !aes_ecb(g_aes_key, DL_AES_DIR_DECRYPT, cipher, plain, blocks))
        {
            uart_puts("ERR el motor AES no respondio");
            prompt();
            return;
        }
        plain[blocks * 16UL] = '\0';
        uart_puts("TEXTO="); uart_puts((const char *)block);
        uart_puts("\r\nCIFRADO="); put_hex_bytes(cipher, blocks * 16UL);
        uart_puts("\r\nDESCIFRADO="); uart_puts((const char *)plain);
        prompt();
        return;
    }
    uart_puts("ERR uso: AES TEST | AES TEXT palabra(<=32)");
    prompt();
}

static void cmd_dma(char **tok, uint32_t count)
{
    uint32_t words;
    if ((count != 3U) || !text_equal(tok[1], "COPY") || !parse_u32(tok[2], &words) || (words == 0UL) ||
        (words > DMA_MAX_WORDS))
    {
        uart_puts("ERR uso: DMA COPY palabras(1..1024)");
        prompt();
        return;
    }
    for (uint32_t i = 0; i < words; ++i)
    {
        g_dma_src[i] = (i * 0x9E3779B9UL) ^ 0xA5A5A5A5UL;
        g_dma_dst[i] = 0UL;
    }
    uint32_t t0 = DWT_CYCCNT;
    memcpy(g_dma_dst, g_dma_src, words * 4UL);
    g_sink_u = g_dma_dst[words - 1UL];
    const uint32_t c_cpu = DWT_CYCCNT - t0;
    const bool cpu_ok = memcmp(g_dma_dst, g_dma_src, words * 4UL) == 0;

    for (uint32_t i = 0; i < words; ++i) g_dma_dst[i] = 0UL;
    uint32_t c_dma = 0UL, work = 0UL;
    const bool done = dma_copy(g_dma_src, g_dma_dst, words, &c_dma, &work);
    const bool dma_ok = done && (memcmp(g_dma_dst, g_dma_src, words * 4UL) == 0);

    uart_puts("BYTES="); uart_put_u32(words * 4UL);
    uart_puts("\r\nCPU memcpy: CICLOS="); uart_put_u32(c_cpu); uart_puts(cpu_ok ? " OK" : " FAIL");
    uart_puts("\r\nDMA:        CICLOS="); uart_put_u32(c_dma); uart_puts(dma_ok ? " OK" : " FAIL");
    uart_puts(" | la CPU quedo libre y conto "); uart_put_u32(work); uart_puts(" vueltas mientras tanto");
    prompt();
}

static void cmd_fault(char **tok, uint32_t count)
{
    if ((count != 2U) || !text_equal(tok[1], "TMU"))
    {
        uart_puts("ERR uso: FAULT TMU");
        prompt();
        return;
    }
    uart_puts("Apagando CP0 en CPACR y ejecutando una instruccion TMU...\r\n");
    SCB_CPACR &= ~0x3UL;
    __asm volatile ("dsb" ::: "memory");
    __asm volatile ("isb" ::: "memory");
    /*
     * La entrada se lee de una variable volatile DESPUES de apagar CP0. Sin
     * esto el compilador puede adelantar la instruccion CDE antes de escribir
     * CPACR (no es un acceso a memoria) y el fallo no ocurre.
     */
    volatile float input = 1.0f;
    g_sink_f = tmu_sin(input); /* NOCP -> UsageFault -> HardFault */
    uart_puts("No hubo fallo (inesperado)");
    prompt();
}

static void execute_command(char *line)
{
    char *tok[MAX_TOKENS];
    const uint32_t count = split_tokens(line, tok, MAX_TOKENS);
    if (count == 0U)
    {
        uart_puts("> ");
        return;
    }
    if (text_equal(tok[0], "PING"))          { uart_puts("PONG " LAB_VERSION); prompt(); }
    else if (text_equal(tok[0], "HELP"))     { print_help(); }
    else if (text_equal(tok[0], "INFO"))     { cmd_info(); }
    else if (text_equal(tok[0], "ID"))       { cmd_id(); }
    else if (text_equal(tok[0], "PEEK"))     { cmd_peek(tok, count); }
    else if (text_equal(tok[0], "MATH"))     { cmd_math(tok, count); }
    else if (text_equal(tok[0], "BENCH"))    { cmd_bench(tok, count); }
    else if (text_equal(tok[0], "INTEGRAL")) { cmd_integral(tok, count); }
    else if (text_equal(tok[0], "PARK"))     { cmd_park(tok, count); }
    else if (text_equal(tok[0], "CRC"))      { cmd_crc(tok, count); }
    else if (text_equal(tok[0], "AES"))      { cmd_aes(tok, count); }
    else if (text_equal(tok[0], "DMA"))      { cmd_dma(tok, count); }
    else if (text_equal(tok[0], "FAULT"))    { cmd_fault(tok, count); }
    else
    {
        uart_puts("ERR comando desconocido. Escriba HELP");
        prompt();
    }
}

static bool uart_try_getc(char *ch)
{
    uint8_t byte;
    if (!DL_UART_receiveDataCheck(UC1_INST_PTR, &byte))
    {
        return false;
    }
    *ch = (char)byte;
    return true;
}

static void poll_command_console(void)
{
    char ch;
    while (uart_try_getc(&ch))
    {
        if ((ch == '\r') || (ch == '\n'))
        {
            if (g_command_length != 0U)
            {
                uart_puts("\r\n");
                g_command[g_command_length] = '\0';
                execute_command(g_command);
                g_command_length = 0U;
            }
        }
        else if ((ch == '\b') || (ch == 0x7F))
        {
            if (g_command_length != 0U)
            {
                --g_command_length;
                uart_puts("\b \b");
            }
        }
        else if ((ch >= 32) && (ch <= 126) && (g_command_length < (COMMAND_BUFFER_SIZE - 1U)))
        {
            g_command[g_command_length++] = ch;
            uart_putc(ch);
        }
    }
}

/* ------------------------------------------------------------------------ */
/* LED y botones (igual que la version anterior)                            */
/* ------------------------------------------------------------------------ */

static bool button_update(ButtonState *button, bool raw, uint32_t now)
{
    bool pressed_event = false;
    if (raw != button->raw)
    {
        button->raw = raw;
        button->changed_at = now;
    }
    else if ((button->stable != raw) && ((uint32_t)(now - button->changed_at) >= DEBOUNCE_MS))
    {
        button->stable = raw;
        pressed_event = raw;
    }
    return pressed_event;
}

static void brightness_next(uint8_t *level)
{
    ++(*level);
    if (*level >= (uint8_t)(sizeof(g_brightness_steps) / sizeof(g_brightness_steps[0]))) *level = 0U;
}

static void leds_write(uint8_t selected_led, bool pwm_on)
{
    GPIO0->DOUTSET31_0 = LED_RED_MASK;
    GPIO1->DOUTSET31_0 = LED_GREEN_MASK;
    if (pwm_on)
    {
        if (selected_led == 0U) GPIO0->DOUTCLR31_0 = LED_RED_MASK;
        else GPIO1->DOUTCLR31_0 = LED_GREEN_MASK;
    }
}

int main(void)
{
    ButtonState boot_button = {false, false, 0UL};
    ButtonState wake_button = {false, false, 0UL};
    uint8_t selected_led = 0U;
    uint8_t brightness = 2U;
    uint8_t pwm_phase = 0U;
    uint32_t now = 0UL;
    uint32_t next_repeat = 0UL;

    enable_fpu_and_tmu();
    gpio_and_buttons_init();
    uart_init();
    cycle_counter_init();
    accelerators_init();
    uint32_t next_tick = DWT_CYCCNT + (CPU_CLOCK_HZ / 1000UL);

    uart_puts("\r\nAM13E230 LAB v2 (SRAM) LISTO - flash intacta. Escriba HELP");
    prompt();

    for (;;)
    {
        poll_command_console();
        if ((int32_t)(DWT_CYCCNT - next_tick) < 0)
        {
            continue;
        }
        next_tick += (CPU_CLOCK_HZ / 1000UL);
        ++now;

        const bool boot_raw = (GPIO0->DIN31_0 & (BUTTON_BOOT_E2_MASK | BUTTON_BOOT_E1_MASK)) != 0UL;
        const bool wake_raw = (GPIO1->DIN31_0 & BUTTON_WAKE_MASK) == 0UL;

        if (button_update(&boot_button, boot_raw, now)) selected_led ^= 1U;
        if (button_update(&wake_button, wake_raw, now))
        {
            brightness_next(&brightness);
            next_repeat = now + HOLD_START_MS;
        }
        if (wake_button.stable && ((int32_t)(now - next_repeat) >= 0))
        {
            brightness_next(&brightness);
            next_repeat += HOLD_REPEAT_MS;
        }
        if (++pwm_phase >= PWM_STEPS) pwm_phase = 0U;
        leds_write(selected_led, pwm_phase < g_brightness_steps[brightness]);
    }
}

#pragma clang attribute pop
