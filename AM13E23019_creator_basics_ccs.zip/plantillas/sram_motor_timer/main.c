/*
 * ==========================================================================
 *  Proyecto: __NOMBRE__   (SRAM: la flash NO se toca)
 *  Motor paso a paso con driver STEPPERONLINE CL86T (modo PUL/DIR)
 *  VERSION 2: timer + interrupcion (la CPU queda libre)
 *
 *  TIMG4_0 cuenta a 32 MHz y cada 10 us llega a cero -> interrupcion.
 *  La interrupcion TIMG4_0_IRQHandler genera los pulsos y la rampa.
 *  El main solo revisa el boton y los LEDs; el resto del tiempo duerme (WFI).
 *
 *  Conexion: PA3 -> PUL, PA27 -> DIR (con transistor/buffer a 5 V),
 *            PB13 = WAKE, PA5 = LED rojo, PB0 = LED verde.
 *  Mismo comportamiento que la version 1 (sram_motor).
 *
 *  Para ver en CCS (View > Expressions): g_estado, g_frecuencia_hz,
 *  g_pasos, g_ciclos_por_tick (debe dar 320 = 10 us a 32 MHz) y
 *  g_ciclos_isr (cuanto tarda la interrupcion).
 * ==========================================================================
 */

/* -------------------------------------------------------------------------
 * 1. INCLUDES
 * ------------------------------------------------------------------------- */
#include <stdbool.h>
#include <stdint.h>

#include "hw/soc.h"
#include "dl_gpio.h"
#include "dl_timerg.h"   /* DL_TimerG_... (macros hacia DL_Timer_...) */

/* -------------------------------------------------------------------------
 * 2. PINES Y TIMER
 * ------------------------------------------------------------------------- */
#define CPU_CLOCK_HZ    (32000000UL)

#define PUL_PORT        GPIO0              /* PA3  */
#define PUL_PIN         DL_GPIO_PIN(3)
#define DIR_PORT        GPIO0              /* PA27 */
#define DIR_PIN         DL_GPIO_PIN(27)
#define ROJO_PORT       GPIO0              /* PA5 */
#define ROJO_PIN        DL_GPIO_PIN(5)
#define VERDE_PORT      GPIO1              /* PB0 */
#define VERDE_PIN       DL_GPIO_PIN(0)
#define BOTON_PORT      GPIO1              /* PB13 */
#define BOTON_PIN       DL_GPIO_PIN(13)

#define STEP_TIMER      TIMG4              /* SysConfig lo llamaria STEP_TIMER_INST */
#define STEP_TIMER_IRQN TIMG4_0_INT_IRQn

/* -------------------------------------------------------------------------
 * 3. PARAMETROS
 * ------------------------------------------------------------------------- */
#define TICK_HZ         100000U                       /* 1 tick = 10 us */
#define TIMER_CARGA     ((CPU_CLOCK_HZ / TICK_HZ) - 1U) /* 319: cuenta 319..0 = 320 ciclos */
#define TICKS_POR_MS    (TICK_HZ / 1000U)
#define F_MIN_HZ        200U
#define F_MAX_HZ        2000U
#define RAMPA_PASOS     800U
#define DIR_SETUP_TICKS 2U                            /* 20 us */

#define ANTIRREBOTE_MS  20U
#define LARGO_MS        800U

typedef enum { PARADO, ACELERANDO, CRUCERO, FRENANDO } Estado;
typedef enum { NADA, ARRANCAR, PARAR, INVERTIR } Peticion;

/* -------------------------------------------------------------------------
 * 4. VARIABLES COMPARTIDAS main <-> interrupcion (volatile!)
 * ------------------------------------------------------------------------- */
volatile uint32_t g_ms;                    /* +1 cada ms (ISR)               */
volatile Estado   g_estado = PARADO;       /* lo escribe la ISR              */
volatile Peticion g_peticion = NADA;       /* lo escribe main, lo borra ISR  */
volatile uint32_t g_frecuencia_hz;
volatile uint32_t g_pasos;
volatile uint32_t g_ciclos_por_tick;       /* comprobacion del timer         */
volatile uint32_t g_ciclos_isr;            /* duracion de la ISR (maximo)    */

/* solo los usa la ISR */
static uint32_t s_sub_ms, s_r, s_espera, s_dir_espera, s_ticks;
static uint32_t s_cambiar_dir;     /* ticks para invertir DIR (0 = nada) */
static bool     s_pul_alto, s_horario = true, s_invertir;

/* -------------------------------------------------------------------------
 * 5. ARRANQUE
 * ------------------------------------------------------------------------- */
void SystemInit(void)
{
    (*(volatile uint32_t *)0xE000ED88UL) = 0x00F00003UL;  /* CPACR: FPU + TMU */
    (*(volatile uint32_t *)0xE000ED08UL) = 0x20000000UL;  /* VTOR: vectores en SRAM */
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

#define DEMCR       (*(volatile uint32_t *)0xE000EDFCUL)
#define DWT_CTRL    (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT  (*(volatile uint32_t *)0xE0001004UL)

/* -------------------------------------------------------------------------
 * 6. "SYSCONFIG A MANO"
 * ------------------------------------------------------------------------- */
static void gpio_init(void)          /* = SYSCFG_DL_GPIO_init() */
{
    DL_GPIO_reset(GPIO0);
    DL_GPIO_reset(GPIO1);
    DL_GPIO_enablePower(GPIO0);
    DL_GPIO_enablePower(GPIO1);
    while (!DL_GPIO_isPowerEnabled(GPIO0) || !DL_GPIO_isPowerEnabled(GPIO1)) { }

    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PA3);    /* PUL */
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PA27);   /* DIR */
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PA5);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PB0);
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM_PB13,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_clearPins(GPIO0, PUL_PIN | DIR_PIN);
    DL_GPIO_setPins(ROJO_PORT, ROJO_PIN);
    DL_GPIO_setPins(VERDE_PORT, VERDE_PIN);
    DL_GPIO_enableOutput(GPIO0, PUL_PIN | DIR_PIN | ROJO_PIN);
    DL_GPIO_enableOutput(GPIO1, VERDE_PIN);
}

/* = SYSCFG_DL_STEP_TIMER_init(): BUSCLK, /1, prescaler 1, 10 us, periodico,
 *   interrupcion en cero. Mismos pasos que la receta del UART:
 *   reset -> encender -> reloj -> modo -> interrupcion -> habilitar reloj */
static void timer_init(void)
{
    static DL_TimerG_ClockConfig reloj = {
        .clockSel    = DL_TIMER_CLOCK_BUSCLK,
        .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
        .prescale    = 0U,                 /* 0 = dividir entre 1 */
    };
    static DL_TimerG_TimerConfig modo = {
        .timerMode    = DL_TIMER_TIMER_MODE_PERIODIC,
        .period       = TIMER_CARGA,       /* periodo real = (319+1)/32 MHz = 10 us */
        .startTimer   = DL_TIMER_STOP,     /* lo arrancamos al final de main */
        .genIntermInt = DL_TIMER_INTERM_INT_DISABLED,
        .counterVal   = 0U,
    };

    DL_TimerG_reset(STEP_TIMER);
    DL_TimerG_enablePower(STEP_TIMER);
    while (!DL_TimerG_isPowerEnabled(STEP_TIMER)) { }
    DL_TimerG_setClockConfig(STEP_TIMER, &reloj);
    DL_TimerG_initTimerMode(STEP_TIMER, &modo);
    DL_TimerG_enableInterrupt(STEP_TIMER, DL_TIMER_INTERRUPT_ZERO_EVENT);
    DL_TimerG_enableClock(STEP_TIMER);

    /* "Register interrupt" de SysConfig = encender esta linea en el NVIC */
    NVIC_ClearPendingIRQ(STEP_TIMER_IRQN);
    NVIC_EnableIRQ(STEP_TIMER_IRQN);
}

/* -------------------------------------------------------------------------
 * 7. INTERRUPCION DEL TIMER (cada 10 us)
 *    El nombre TIMG4_0_IRQHandler esta en la tabla de vectores del SDK
 *    (startup_ti_arm_clang.c) como "weak": al escribirla aqui, la nuestra gana.
 *    SysConfig la llamaria STEP_TIMER_INT_Handler.
 * ------------------------------------------------------------------------- */
static uint32_t periodo_ticks(uint32_t r)
{
    const uint32_t f = F_MIN_HZ + ((F_MAX_HZ - F_MIN_HZ) * r) / RAMPA_PASOS;
    g_frecuencia_hz = f;
    return TICK_HZ / f;             /* 200 Hz -> 500 ticks ; 2 kHz -> 50 ticks */
}

static void escribir_dir(bool horario)
{
    if (horario) DL_GPIO_setPins(DIR_PORT, DIR_PIN);
    else         DL_GPIO_clearPins(DIR_PORT, DIR_PIN);
}

static void isr_motor(void)
{
    /* el pulso dura exactamente 1 tick = 10 us */
    if (s_pul_alto) {
        DL_GPIO_clearPins(PUL_PORT, PUL_PIN);
        s_pul_alto = false;
    }

    /* invertir DIR pendiente: se hace 1 tick DESPUES de que bajo el pulso,
     * nunca mientras PUL esta arriba */
    if (s_cambiar_dir > 0U) {
        if (--s_cambiar_dir == 0U) {
            s_horario = !s_horario;
            escribir_dir(s_horario);
            s_dir_espera = DIR_SETUP_TICKS;
        }
        return;
    }

    const Peticion p = g_peticion;
    if (p != NADA) {
        g_peticion = NADA;
        if (p == ARRANCAR && g_estado == PARADO) {
            s_r = 0U; s_espera = 0U; s_dir_espera = DIR_SETUP_TICKS;
            escribir_dir(s_horario);
            g_estado = ACELERANDO;
        } else if (p == PARAR && g_estado != PARADO) {
            s_invertir = false;
            g_estado = FRENANDO;
        } else if (p == INVERTIR) {
            if (g_estado == PARADO) { s_horario = !s_horario; escribir_dir(s_horario); }
            else                    { s_invertir = true; g_estado = FRENANDO; }
        }
    }

    if (g_estado == PARADO)      { g_frecuencia_hz = 0U; return; }
    if (s_dir_espera > 0U)       { s_dir_espera--; return; }
    if (s_espera > 0U)           { s_espera--;     return; }

    /* toca un paso */
    DL_GPIO_setPins(PUL_PORT, PUL_PIN);
    s_pul_alto = true;
    g_pasos++;

    if (g_estado == ACELERANDO) {
        if (++s_r >= RAMPA_PASOS) { s_r = RAMPA_PASOS; g_estado = CRUCERO; }
    } else if (g_estado == FRENANDO) {
        if (s_r > 0U) { s_r--; }
        if (s_r == 0U) {
            if (s_invertir) {
                s_invertir = false;
                s_cambiar_dir = 2U;               /* tick+1 baja PUL, tick+2 cambia DIR */
                s_espera = 0U;
                g_estado = ACELERANDO;
                return;
            } else {
                g_estado = PARADO;
                return;
            }
        }
    }
    s_espera = periodo_ticks(s_r) - 1U;           /* -1: este tick ya cuenta */
}

void TIMG4_0_IRQHandler(void)
{
    static uint32_t marca;
    const uint32_t entrada = DWT_CYCCNT;

    /* Leer IIDX dice QUE paso y ademas BORRA la bandera (como en el UART) */
    if (DL_TimerG_getPendingInterrupt(STEP_TIMER) != DL_TIMER_IIDX_ZERO) {
        return;
    }

    if (++s_sub_ms >= TICKS_POR_MS) { s_sub_ms = 0U; g_ms++; }
    if (++s_ticks >= 1000U) {                      /* cada 10 ms: medir el timer */
        g_ciclos_por_tick = (entrada - marca) / 1000U;
        marca = entrada;
        s_ticks = 0U;
    }

    isr_motor();

    const uint32_t dur = DWT_CYCCNT - entrada;
    if (dur > g_ciclos_isr) g_ciclos_isr = dur;
}

/* -------------------------------------------------------------------------
 * 8. MAIN: boton y LEDs
 * ------------------------------------------------------------------------- */
static void leds(bool girando)
{
    if (girando) {
        DL_GPIO_clearPins(VERDE_PORT, VERDE_PIN);
        DL_GPIO_setPins(ROJO_PORT, ROJO_PIN);
    } else {
        DL_GPIO_setPins(VERDE_PORT, VERDE_PIN);
        DL_GPIO_clearPins(ROJO_PORT, ROJO_PIN);
    }
}

int main(void)
{
    DEMCR |= (1UL << 24);            /* contador de ciclos para las mediciones */
    DWT_CYCCNT = 0UL;
    DWT_CTRL |= 1UL;

    gpio_init();
    timer_init();
    escribir_dir(true);
    leds(false);
    DL_TimerG_startCounter(STEP_TIMER);   /* desde aqui hay tick de 10 us */

    bool     crudo = false, estable = false, largo_hecho = false;
    uint32_t cambio_ms = 0U, presion_ms = 0U, ultimo_ms = 0U;

    for (;;)
    {
        __WFI();                              /* dormir hasta la siguiente interrupcion */
        const uint32_t ahora_ms = g_ms;
        if (ahora_ms == ultimo_ms) continue;  /* el resto, 1 vez por ms */
        ultimo_ms = ahora_ms;

        leds(g_estado != PARADO);

        const bool c = (DL_GPIO_readPins(BOTON_PORT, BOTON_PIN) == 0UL);
        if (c != crudo) { crudo = c; cambio_ms = ahora_ms; }
        if ((estable != crudo) && ((ahora_ms - cambio_ms) >= ANTIRREBOTE_MS)) {
            estable = crudo;
            if (estable) { presion_ms = ahora_ms; largo_hecho = false; }
            else if (!largo_hecho) {
                g_peticion = (g_estado == PARADO) ? ARRANCAR : PARAR;   /* CORTA */
            }
        }
        if (estable && !largo_hecho && ((ahora_ms - presion_ms) >= LARGO_MS)) {
            largo_hecho = true;
            g_peticion = INVERTIR;                                      /* LARGA */
        }

        /* >>> AQUI: puedes agregar trabajo (UART, calculos...). Aunque tarde,
         *     los pulsos siguen exactos porque los genera la interrupcion. */
    }
}
