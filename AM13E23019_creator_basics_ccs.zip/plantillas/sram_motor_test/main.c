/*
 * ==========================================================================
 *  Proyecto: __NOMBRE__   (SRAM: la flash NO se toca)
 *  PRUEBA DE CABLEADO para el driver CL86T: deja PA3 (PUL) y PA27 (DIR)
 *  FIJOS en 0 o en 1, para medirlos con el multimetro con calma.
 *  (El programa real del motor los pulsa a 10 us; eso no se puede medir
 *  con multimetro. Este programa es solo para probar que el cableado
 *  de los transistores esta bien ANTES de correr el motor de verdad.)
 *
 *  Boton PB13 (WAKE):
 *    - Pulsacion CORTA: cambia PUL (PA3) entre 0 y 1.
 *    - Pulsacion LARGA (>= 800 ms): cambia DIR (PA27) entre 0 y 1.
 *
 *  LEDs (te dicen el estado sin necesidad de ver CCS):
 *    - LED rojo (PA5)  ENCENDIDO = PUL esta en 1.
 *    - LED verde (PB0) ENCENDIDO = DIR esta en 1.
 *    (Los dos APAGADOS = PUL=0, DIR=0; el estado de arranque.)
 *
 *  Como usarlo:
 *    1. Arma SOLO el circuito de PUL primero (transistor + 2 resistencias).
 *    2. Carga este programa (Debug en CCS). Arranca con PUL=0, DIR=0,
 *       los dos LEDs apagados.
 *    3. Mide con el multimetro en DC entre PUL+ y PUL- del driver: debe
 *       dar casi 0 V.
 *    4. Pulsacion CORTA al boton: el LED rojo prende (PUL=1). Mide de
 *       nuevo: debe dar unos 4.7-4.9 V.
 *    5. Si eso sale bien, arma el circuito de DIR y repite con pulsacion
 *       LARGA (LED verde) y el multimetro en DIR+/DIR-.
 * ==========================================================================
 */

/* -------------------------------------------------------------------------
 * 1. INCLUDES
 * ------------------------------------------------------------------------- */
#include <stdbool.h>
#include <stdint.h>

#include "hw/soc.h"     /* registros y nombres de pines (IOMUX_PINCM_PA3...) */
#include "dl_gpio.h"    /* DL_GPIO_... (las mismas que usa SysConfig) */

/* -------------------------------------------------------------------------
 * 2. PINES
 * ------------------------------------------------------------------------- */
#define CPU_CLOCK_HZ    (32000000UL)       /* reloj por defecto, sin PLL */

#define PUL_PORT        GPIO0              /* PA3  -> PUL+ del driver (via transistor) */
#define PUL_PIN         DL_GPIO_PIN(3)
#define PUL_IOMUX       IOMUX_PINCM_PA3
#define DIR_PORT        GPIO0              /* PA27 -> DIR+ del driver (via transistor) */
#define DIR_PIN         DL_GPIO_PIN(27)
#define DIR_IOMUX       IOMUX_PINCM_PA27
#define ROJO_PORT       GPIO0              /* PA5, activo en bajo */
#define ROJO_PIN        DL_GPIO_PIN(5)
#define VERDE_PORT      GPIO1              /* PB0, activo en bajo */
#define VERDE_PIN       DL_GPIO_PIN(0)
#define BOTON_PORT      GPIO1              /* PB13 WAKE: 0 = presionado */
#define BOTON_PIN       DL_GPIO_PIN(13)

#define ANTIRREBOTE_MS  20U
#define LARGO_MS        800U

/* -------------------------------------------------------------------------
 * 3. ARRANQUE: lo llama Reset_Handler (arranque_ccs.c) antes de main
 * ------------------------------------------------------------------------- */
void SystemInit(void)
{
    (*(volatile uint32_t *)0xE000ED88UL) = 0x00F00003UL;  /* CPACR: FPU + TMU */
    (*(volatile uint32_t *)0xE000ED08UL) = 0x20000000UL;  /* VTOR: vectores en SRAM */
    __asm volatile ("dsb");
    __asm volatile ("isb");
}

/* -------------------------------------------------------------------------
 * 4. "SYSCONFIG A MANO": lo mismo que generaria SYSCFG_DL_GPIO_init()
 * ------------------------------------------------------------------------- */
static void gpio_init(void)
{
    DL_GPIO_reset(GPIO0);
    DL_GPIO_reset(GPIO1);
    DL_GPIO_enablePower(GPIO0);
    DL_GPIO_enablePower(GPIO1);
    while (!DL_GPIO_isPowerEnabled(GPIO0) || !DL_GPIO_isPowerEnabled(GPIO1)) { }

    DL_GPIO_initDigitalOutput(PUL_IOMUX);
    DL_GPIO_initDigitalOutput(DIR_IOMUX);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PA5);
    DL_GPIO_initDigitalOutput(IOMUX_PINCM_PB0);
    DL_GPIO_initDigitalInputFeatures(IOMUX_PINCM_PB13,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP, DL_GPIO_WAKEUP_DISABLE);

    /* arranca en 0,0: ambos LEDs apagados */
    DL_GPIO_clearPins(GPIO0, PUL_PIN | DIR_PIN);
    DL_GPIO_setPins(ROJO_PORT, ROJO_PIN);    /* LED apagado (activo en bajo) */
    DL_GPIO_setPins(VERDE_PORT, VERDE_PIN);
    DL_GPIO_enableOutput(GPIO0, PUL_PIN | DIR_PIN | ROJO_PIN);
    DL_GPIO_enableOutput(GPIO1, VERDE_PIN);
}

/* -------------------------------------------------------------------------
 * 5. RELOJ: contador de ciclos del nucleo (DWT), para contar milisegundos
 * ------------------------------------------------------------------------- */
#define DEMCR       (*(volatile uint32_t *)0xE000EDFCUL)
#define DWT_CTRL    (*(volatile uint32_t *)0xE0001000UL)
#define DWT_CYCCNT  (*(volatile uint32_t *)0xE0001004UL)

static void cronometro_init(void)
{
    DEMCR |= (1UL << 24);
    DWT_CYCCNT = 0UL;
    DWT_CTRL |= 1UL;
}

/* -------------------------------------------------------------------------
 * 6. MAIN: revisa el boton cada 1 ms, nada mas
 * ------------------------------------------------------------------------- */
int main(void)
{
    gpio_init();
    cronometro_init();

    bool     pul_estado = false, dir_estado = false;
    bool     crudo = false, estable = false, largo_hecho = false;
    uint32_t ahora_ms = 0U, cambio_ms = 0U, presion_ms = 0U;
    uint32_t siguiente_tick = DWT_CYCCNT + (CPU_CLOCK_HZ / 1000UL);

    for (;;)
    {
        /* esperar al siguiente milisegundo (sin pulsar nada: PUL y DIR
         * se quedan fijos todo el tiempo, por eso se pueden medir) */
        if ((int32_t)(DWT_CYCCNT - siguiente_tick) < 0) { continue; }
        siguiente_tick += (CPU_CLOCK_HZ / 1000UL);
        ++ahora_ms;

        const bool c = (DL_GPIO_readPins(BOTON_PORT, BOTON_PIN) == 0UL);
        if (c != crudo) { crudo = c; cambio_ms = ahora_ms; }
        if ((estable != crudo) && ((ahora_ms - cambio_ms) >= ANTIRREBOTE_MS)) {
            estable = crudo;
            if (estable) {
                presion_ms = ahora_ms;
                largo_hecho = false;
            } else if (!largo_hecho) {
                /* CORTA: invertir PUL */
                pul_estado = !pul_estado;
                if (pul_estado) { DL_GPIO_setPins(PUL_PORT, PUL_PIN); DL_GPIO_clearPins(ROJO_PORT, ROJO_PIN); }
                else            { DL_GPIO_clearPins(PUL_PORT, PUL_PIN); DL_GPIO_setPins(ROJO_PORT, ROJO_PIN); }
            }
        }
        if (estable && !largo_hecho && ((ahora_ms - presion_ms) >= LARGO_MS)) {
            largo_hecho = true;
            /* LARGA: invertir DIR */
            dir_estado = !dir_estado;
            if (dir_estado) { DL_GPIO_setPins(DIR_PORT, DIR_PIN); DL_GPIO_clearPins(VERDE_PORT, VERDE_PIN); }
            else            { DL_GPIO_clearPins(DIR_PORT, DIR_PIN); DL_GPIO_setPins(VERDE_PORT, VERDE_PIN); }
        }
    }
}
