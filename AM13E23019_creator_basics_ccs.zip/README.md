# Creador de proyectos CCS - LP-AM13E230

Generador de proyectos **nativos de Code Composer Studio (CCS 21)** para la
LaunchPad **LP-AM13E230** (AM13E23019, Cortex-M33), compilados con
**TI Arm Clang 5.1.1**.

Con un doble clic arma una carpeta de proyecto lista para abrir en CCS
(`File > Open Folder`), compilar (`Build`) y cargar/depurar (`Debug`), a
partir de una plantilla ya probada: consola por UART, motor paso a paso,
laboratorio de periféricos, etc. No hay que armar el proyecto a mano en CCS
ni tocar el linker.

## Requisitos

- Windows con **Code Composer Studio 21** instalado en `C:\ti\ccs2101`.
- **SDK de TI** `am13e230x_sdk_26_01_00_03` en `C:\ti\am13e230x_sdk_26_01_00_03`.
- PowerShell (ya viene en Windows).
- LaunchPad **LP-AM13E230** conectada por USB para cargar/depurar.

Si tu instalación está en otras rutas, ajusta las variables al inicio de
`CREADOR_CCS.ps1` (`$cli`, `$sdkDir`).

## Uso rápido

1. Doble clic en **`CREAR_PROYECTO_CCS.cmd`**.
2. Elige un tipo de plantilla (1-8, ver tabla abajo).
3. Escribe el nombre del proyecto y, si quieres, la carpeta destino
   (por defecto `TI\ccs_proyectos`).
4. Abre CCS → `File > Open Folder` → la carpeta que se generó.
5. `Build` para compilar, `Debug` para cargar en la placa.

También se puede llamar directo desde PowerShell, por ejemplo:

```powershell
.\CREADOR_CCS.ps1 -Tipo sram_motor_uart -Nombre mi_motor -Destino C:\ti\ccs_proyectos
```

## Plantillas disponibles

| # | Tipo                | Qué trae                                                              |
|---|----------------------|------------------------------------------------------------------------|
| 1 | `sram`               | Consola por UART (PING, HELP, LED) como base para tus propios comandos |
| 2 | `sram_irq`           | Consola con interrupciones (modo sondeo/IRQ, espera)                   |
| 3 | `sram_lab`           | Laboratorio completo: TMU, Park, integral, CRC, AES, DMA                |
| 4 | `sram_motor_test`    | Prueba de cableado PUL/DIR del driver CL86T (voltajes fijos, para medir con multímetro) |
| 5 | `sram_motor`         | Motor paso a paso con driver CL86T (PUL/DIR), control por busy-wait     |
| 6 | `sram_motor_timer`   | Motor paso a paso CL86T con timer + interrupción (no bloquea la CPU)    |
| 7 | `sram_motor_uart`    | Motor CL86T controlado por UART y por el botón físico a la vez (ARRANCA, PARA, GIRA, VEL, PASOS +/-) |
| 8 | `flash`              | GPIO básico: LED parpadea, botón BOOT cambia LED, WAKE cambia velocidad |

### SRAM vs FLASH

- **SRAM** (tipos 1-3 y 5-7): el programa se carga en memoria temporal. Al
  reiniciar la placa o desconectarla, se borra. **La flash nunca se toca.**
  Pensado para ir probando y aprendiendo sin arriesgar lo que ya tengas
  grabado.
- **FLASH** (tipo 8): `Debug` graba la flash de verdad, reemplazando el
  programa que esté guardado ahí. Usa `plantillas/comun/HUELLA_FLASH.bat`
  antes para guardar una copia de lo que hay, por si quieres comparar o
  regresar.

## Proyectos de motor (CL86T + NEMA 34)

Los tipos 4, 5, 6 y 7 están pensados para un driver **STEPPERONLINE CL86T**
en modo PUL/DIR, con `PA3` → PUL y `PA27` → DIR a través de un transistor
NPN (la LaunchPad da 3.3V y el opto del driver necesita 5V). Cada uno de
estos proyectos trae su propio `LEEME_CONEXION.txt` con el circuito exacto,
las advertencias de aislamiento de tierras y los primeros pasos de prueba
con el motor sin carga.

Empieza siempre por `sram_motor_test` (4) para confirmar el cableado con un
multímetro antes de mover el motor de verdad.

## Estructura del repositorio

```
CREAR_PROYECTO_CCS.cmd     Punto de entrada (doble clic)
CREADOR_CCS.ps1            Script que arma el proyecto de CCS
PROBAR_CREADOR_CCS.cmd     Prueba: genera y compila los tipos de consola/lab (no toca la placa)
PROBAR_EN_PLACA.cmd        Prueba: carga proyectos SRAM en la placa real y los interroga por UART
PROBAR_MOTOR.bat           Prueba: genera y compila los proyectos de motor
plantillas/
  comun/                   Arranque, linkers, y utilidades (consola UART, huella de flash, etc.)
  flash/                   Plantilla FLASH
  sram/, sram_irq/, sram_lab/        Plantillas de consola/laboratorio
  sram_motor*/             Plantillas del motor paso a paso (cada una con su LEEME_CONEXION.txt)
```

## Notas

- Dentro de los proyectos generados, las utilidades son `.bat` y no `.cmd`,
  porque CCS trata cualquier `.cmd` como archivo del linker.
- Los scripts `PROBAR_*` son de desarrollo/regresión (arman y compilan todo
  para detectar roturas); se pueden borrar sin afectar al creador.
